# Sudhanshu Sharma - Portfolio Website

A comprehensive, production-ready personal portfolio website showcasing advanced technical skills and serving as an effective recruitment tool.

## 🌟 Features

### Core Functionality
- **Interactive Hero Section** with animated typing effects and particle background
- **AI-Powered Tools** including resume analyzer and cover letter generator
- **Live Code Sandbox** with real-time preview and syntax highlighting
- **Interactive Terminal** with custom commands and animations
- **Tech Timeline** with scroll-triggered animations
- **Skills Grid** with hover tooltips and proficiency ratings
- **Project Showcase** with detailed descriptions and live demos
- **Contact Form** with validation and success feedback

### Advanced Features
- **Multilingual Support** (English/Hindi toggle)
- **Interactive Chatbot** with predefined responses
- **Certificate Gallery** with modal views
- **Interactive Map** integration
- **Particle Animation** background
- **Responsive Design** across all devices
- **Performance Optimized** for Core Web Vitals

### Interactive Elements
- **Animated Avatar** with breathing effects and eye tracking
- **Terminal Mode** with custom commands like `sudo hire me`
- **AI Resume Analyzer** with file upload and analysis
- **Cover Letter Generator** with personalized content
- **Confetti Animations** for special interactions
- **Smooth Scrolling** and hover effects throughout

## 🚀 Tech Stack

- **Frontend**: React 18, TypeScript
- **Styling**: Tailwind CSS with custom animations
- **Icons**: Lucide React
- **Build Tool**: Vite
- **Language**: TypeScript for type safety

## 📱 Responsive Breakpoints

- **Mobile**: 320px - 767px
- **Tablet**: 768px - 1023px  
- **Desktop**: 1024px - 1439px
- **Large Desktop**: 1440px+

## ⚡ Performance Features

- **Lazy Loading** for images and components
- **Code Splitting** for optimal bundle size
- **Optimized Images** with proper sizing
- **Smooth 60fps Animations** throughout
- **Core Web Vitals** optimized (LCP <2.5s, FID <100ms, CLS <0.1)

## 🎯 Accessibility

- **WCAG 2.1 AA Compliance**
- **Keyboard Navigation** for all interactive elements
- **Screen Reader** compatibility
- **High Contrast** support
- **Reduced Motion** respect for user preferences

## 🛠️ Setup Instructions

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd sudhanshu-portfolio
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start development server**
   ```bash
   npm run dev
   ```

4. **Build for production**
   ```bash
   npm run build
   ```

5. **Preview production build**
   ```bash
   npm run preview
   ```

## 🎮 Interactive Features

### Terminal Commands
- `help` - Show all available commands
- `whoami` - Display profile information
- `skills` - List technical skills with ratings
- `show projects` - Scroll to projects section
- `sudo hire me` - Download resume with confetti animation
- `cd future` - Display career aspirations
- `cat secrets.md` - Show developer easter eggs
- `clear` - Clear terminal screen
- `exit` - Close terminal

### AI Tools
- **Resume Analyzer**: Upload resume for AI-powered analysis
- **Cover Letter Generator**: Create personalized cover letters

### Chatbot Responses
The chatbot responds to queries about:
- Technologies and skills
- Project details and experience
- Contact information
- Career background

## 🎨 Design System

### Colors
- **Primary**: Blue (#3B82F6)
- **Secondary**: Teal (#14B8A6)
- **Accent**: Orange (#F97316)
- **Success**: Green (#10B981)
- **Warning**: Yellow (#F59E0B)
- **Error**: Red (#EF4444)

### Typography
- **Font Family**: Inter (Google Fonts)
- **Headings**: 700 weight
- **Body**: 400 weight
- **Line Heights**: 150% for body, 120% for headings

### Animations
- **Float**: 6s infinite for avatar
- **Breathing**: 3s infinite for avatar
- **Typing**: Real-time with cursor blink
- **Particles**: Continuous subtle movement
- **Scroll Triggers**: Staggered element reveals

## 📊 Performance Metrics

Target metrics for optimal user experience:
- **Lighthouse Performance**: >90
- **First Contentful Paint**: <1.5s
- **Largest Contentful Paint**: <2.5s
- **Time to Interactive**: <3.5s
- **Cumulative Layout Shift**: <0.1

## 🌍 Browser Support

- **Chrome**: Latest 2 versions
- **Firefox**: Latest 2 versions
- **Safari**: Latest 2 versions
- **Edge**: Latest 2 versions

## 📞 Contact Information

- **Email**: sudhanshu.sharma.vs@gmail.com
- **LinkedIn**: [sudhanshu-sharma-1745b8324](https://linkedin.com/in/sudhanshu-sharma-1745b8324)
- **GitHub**: [SuDhAnShU-shr](https://github.com/SuDhAnShU-shr)
- **Location**: Phagwara, Punjab, India

## 🏆 Key Achievements

- **15+ Projects** completed across various technologies
- **7+ Technologies** mastered with hands-on experience
- **Volunteer Work** at LPU university events
- **Multiple Certifications** in leadership and technical skills

## 🔧 Development Commands

```bash
# Development
npm run dev          # Start development server
npm run build        # Build for production
npm run preview      # Preview production build
npm run lint         # Run ESLint
npm run type-check   # Run TypeScript checks

# Testing
npm run test         # Run tests (when configured)
npm run test:watch   # Run tests in watch mode
```

## 📈 Future Enhancements

- **Blog Section** for technical articles
- **Dark Mode** toggle
- **Progressive Web App** features
- **Advanced Analytics** integration
- **Content Management System** for easy updates

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

---

**Built with ❤️ by Sudhanshu Sharma** | **Made in India 🇮🇳**