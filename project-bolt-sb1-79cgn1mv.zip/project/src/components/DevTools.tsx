import React, { useState, useEffect } from 'react';
import { Code, RefreshCw, Maximize } from 'lucide-react';

const DevTools = () => {
  const [htmlCode, setHtmlCode] = useState(`<div class="container">
  <h1>Welcome to Code Sandbox!</h1>
  <button class="animated-btn" onclick="showMessage()">
    Click Me!
  </button>
  <div id="message"></div>
</div>`);

  const [cssCode, setCssCode] = useState(`.container {
  padding: 20px;
  font-family: 'Inter', sans-serif;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: white;
}

h1 {
  font-size: 2.5rem;
  margin-bottom: 2rem;
  text-align: center;
  text-shadow: 0 2px 4px rgba(0,0,0,0.3);
}

.animated-btn {
  background: #3B82F6;
  color: white;
  border: none;
  padding: 1rem 2rem;
  border-radius: 0.5rem;
  font-size: 1.1rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}

.animated-btn:hover {
  background: #1E40AF;
  transform: translateY(-2px);
  box-shadow: 0 8px 15px rgba(0,0,0,0.2);
}

#message {
  margin-top: 2rem;
  padding: 1rem;
  background: rgba(255,255,255,0.1);
  border-radius: 0.5rem;
  backdrop-filter: blur(10px);
  text-align: center;
  min-height: 60px;
  opacity: 0;
  transition: all 0.3s ease;
}

#message.show {
  opacity: 1;
  transform: scale(1.05);
}`);

  const [jsCode, setJsCode] = useState(`function showMessage() {
  const messages = [
    "Hello from the sandbox! 👋",
    "Great job clicking the button! 🎉",
    "You're exploring the code sandbox! 🚀",
    "Keep experimenting with the code! 💻",
    "This is interactive coding! ✨"
  ];
  
  const messageElement = document.getElementById('message');
  const randomMessage = messages[Math.floor(Math.random() * messages.length)];
  
  messageElement.textContent = randomMessage;
  messageElement.classList.add('show');
  
  // Add some sparkle effect
  createSparkles();
}

function createSparkles() {
  const container = document.querySelector('.container');
  
  for (let i = 0; i < 10; i++) {
    const sparkle = document.createElement('div');
    sparkle.style.cssText = \`
      position: absolute;
      width: 4px;
      height: 4px;
      background: #FFD700;
      border-radius: 50%;
      pointer-events: none;
      left: \${Math.random() * 100}%;
      top: \${Math.random() * 100}%;
      animation: sparkle 1s ease-out forwards;
    \`;
    
    container.appendChild(sparkle);
    
    setTimeout(() => {
      if (container.contains(sparkle)) {
        container.removeChild(sparkle);
      }
    }, 1000);
  }
}`);

  const [previewCode, setPreviewCode] = useState('');

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      updatePreview();
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [htmlCode, cssCode, jsCode]);

  const updatePreview = () => {
    const preview = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Code Preview</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }
        @keyframes sparkle {
            0% {
                transform: scale(0) rotate(0deg);
                opacity: 1;
            }
            100% {
                transform: scale(1) rotate(180deg);
                opacity: 0;
            }
        }
        ${cssCode}
    </style>
</head>
<body>
    ${htmlCode}
    <script>
        try {
            ${jsCode}
        } catch (error) {
            console.error('JavaScript Error:', error);
        }
    </script>
</body>
</html>`;
    setPreviewCode(preview);
  };

  const resetCode = () => {
    setHtmlCode(`<div class="container">
  <h1>Welcome to Code Sandbox!</h1>
  <button class="animated-btn" onclick="showMessage()">
    Click Me!
  </button>
  <div id="message"></div>
</div>`);
    setCssCode(`.container {
  padding: 20px;
  font-family: 'Inter', sans-serif;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: white;
}`);
    setJsCode(`function showMessage() {
  const messages = [
    "Hello from the sandbox! 👋",
    "You're back to the start! 🔄"
  ];
  
  const messageElement = document.getElementById('message');
  const randomMessage = messages[Math.floor(Math.random() * messages.length)];
  
  messageElement.textContent = randomMessage;
  messageElement.classList.add('show');
}`);
  };

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Developer Tools</h2>
          <p className="text-xl text-gray-600">Interactive coding environment</p>
        </div>

        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          {/* Header */}
          <div className="bg-gray-900 text-white p-4 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Code className="w-5 h-5" />
              <h3 className="font-semibold">Live Code Sandbox</h3>
            </div>
            <div className="flex space-x-2">
              <button
                onClick={resetCode}
                className="flex items-center space-x-1 px-3 py-1 bg-gray-700 hover:bg-gray-600 rounded text-sm transition-colors"
              >
                <RefreshCw className="w-4 h-4" />
                <span>Reset</span>
              </button>
              <button className="flex items-center space-x-1 px-3 py-1 bg-gray-700 hover:bg-gray-600 rounded text-sm transition-colors">
                <Maximize className="w-4 h-4" />
                <span>Fullscreen</span>
              </button>
            </div>
          </div>

          {/* Editor */}
          <div className="grid grid-cols-1 lg:grid-cols-2 h-96 lg:h-[600px]">
            {/* Code Editors */}
            <div className="flex flex-col border-r border-gray-200">
              {/* HTML Editor */}
              <div className="flex-1 border-b border-gray-200">
                <div className="bg-gray-100 px-4 py-2 border-b border-gray-200 flex items-center space-x-2">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <span className="text-sm font-medium text-gray-700">HTML</span>
                </div>
                <textarea
                  value={htmlCode}
                  onChange={(e) => setHtmlCode(e.target.value)}
                  className="w-full h-full p-4 font-mono text-sm resize-none border-none outline-none bg-gray-50"
                  spellCheck={false}
                />
              </div>

              {/* CSS Editor */}
              <div className="flex-1 border-b border-gray-200">
                <div className="bg-gray-100 px-4 py-2 border-b border-gray-200 flex items-center space-x-2">
                  <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                  <span className="text-sm font-medium text-gray-700">CSS</span>
                </div>
                <textarea
                  value={cssCode}
                  onChange={(e) => setCssCode(e.target.value)}
                  className="w-full h-full p-4 font-mono text-sm resize-none border-none outline-none bg-gray-50"
                  spellCheck={false}
                />
              </div>

              {/* JavaScript Editor */}
              <div className="flex-1">
                <div className="bg-gray-100 px-4 py-2 border-b border-gray-200 flex items-center space-x-2">
                  <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                  <span className="text-sm font-medium text-gray-700">JavaScript</span>
                </div>
                <textarea
                  value={jsCode}
                  onChange={(e) => setJsCode(e.target.value)}
                  className="w-full h-full p-4 font-mono text-sm resize-none border-none outline-none bg-gray-50"
                  spellCheck={false}
                />
              </div>
            </div>

            {/* Preview */}
            <div className="flex flex-col">
              <div className="bg-gray-100 px-4 py-2 border-b border-gray-200 flex items-center space-x-2">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span className="text-sm font-medium text-gray-700">Preview</span>
              </div>
              <iframe
                srcDoc={previewCode}
                className="w-full h-full border-none"
                sandbox="allow-scripts"
                title="Code Preview"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DevTools;