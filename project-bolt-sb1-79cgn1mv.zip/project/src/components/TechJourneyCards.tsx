import { useState } from "react";
import { motion } from "framer-motion";

const techData = [
  {
    title: "HTML, CSS, JavaScript",
    short: "Frontend Web Development",
    details: `HTML (1991, Tim Berners-Lee): Structures web pages.
CSS (1996, Håkon Wium Lie): Styles websites.
JavaScript (1995, Brendan Eich): Adds interactivity.
Essential for building modern, responsive web apps.`
  },
  {
    title: "Python",
    short: "Versatile Programming Language",
    details: `Python (1991, Guido van Rossum): Used in AI, web, automation.
Top language for beginners and data scientists.
Widely used by Google, Netflix, NASA.`
  },
  {
    title: "C, DBMS",
    short: "System & Data Foundations",
    details: `C (1972, Dennis Ritchie): Core system programming language.
DBMS (1970, E.F. Codd): Manages structured data.
SQL (1974, Donald Chamberlin): Essential for databases.`
  },
  {
    title: "DevOps & Cloud",
    short: "Docker, Kubernetes, AWS & More",
    details: `Docker (2013, Solomon Hykes): Containers.
Kubernetes (2014, Google): Orchestrator.
Linux (1991, Linus Torvalds): Server OS.
AWS (2006, Amazon): Cloud leader.
Jenkins (2011): CI/CD automation.
Flask (2010): Lightweight Python framework.
MongoDB (2009): NoSQL database.`
  }
];

export default function TechJourneyCards() {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 gap-6 p-6 bg-gray-900 min-h-screen text-white">
      {techData.map((tech, index) => (
        <motion.div
          key={index}
          className="relative bg-gray-800 rounded-2xl p-6 shadow-xl overflow-hidden"
          whileHover={{ scale: 1.05 }}
          onHoverStart={() => setHoveredIndex(index)}
          onHoverEnd={() => setHoveredIndex(null)}
        >
          <h2 className="text-xl font-bold mb-2">{tech.title}</h2>
          <p className="text-gray-400">{tech.short}</p>

          {hoveredIndex === index && (
            <motion.div
              className="absolute inset-0 bg-gray-950 bg-opacity-95 p-6 rounded-2xl z-10 text-sm leading-relaxed"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
            >
              <h3 className="text-lg font-semibold mb-2">Details</h3>
              <pre className="whitespace-pre-wrap text-gray-300">{tech.details}</pre>
            </motion.div>
          )}
        </motion.div>
      ))}
    </div>
  );
}