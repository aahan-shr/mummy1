import React, { useEffect, useRef, useState } from 'react';
import { Code, Database, Server, Cloud } from 'lucide-react';

const Timeline = () => {
  const [visibleItems, setVisibleItems] = useState<Set<number>>(new Set());
  const timelineRef = useRef<HTMLDivElement>(null);

  const timelineData = [
    {
      date: 'Aug 2024',
      title: 'Frontend Foundation',
      description: 'Started with HTML, CSS, and JavaScript fundamentals',
      icon: Code,
      techs: ['HTML', 'CSS', 'JavaScript'],
      color: 'blue'
    },
    {
      date: 'Oct 2024',
      title: 'Backend Development',
      description: 'Dove into Python programming and backend concepts',
      icon: Server,
      techs: ['Python'],
      color: 'green'
    },
    {
      date: 'Feb 2025',
      title: 'Systems Programming',
      description: 'Mastered C programming and database management',
      icon: Database,
      techs: ['C', 'DBMS'],
      color: 'purple'
    },
    {
      date: 'July 2025',
      title: 'DevOps & Cloud',
      description: 'Embraced modern deployment and cloud technologies',
      icon: Cloud,
      techs: ['Docker', 'Kubernetes', 'Linux', 'AWS', 'Jenkins', 'Flask', 'MongoDB'],
      color: 'orange'
    }
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const index = Number(entry.target.getAttribute('data-index'));
            setVisibleItems(prev => new Set([...prev, index]));
          }
        });
      },
      { threshold: 0.3 }
    );

    const timelineItems = document.querySelectorAll('.timeline-item');
    timelineItems.forEach(item => observer.observe(item));

    return () => observer.disconnect();
  }, []);

  const getColorClasses = (color: string) => {
    const colors = {
      blue: 'bg-blue-500 border-blue-200 text-blue-700',
      green: 'bg-green-500 border-green-200 text-green-700',
      purple: 'bg-purple-500 border-purple-200 text-purple-700',
      orange: 'bg-orange-500 border-orange-200 text-orange-700'
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Learning Journey</h2>
          <p className="text-xl text-gray-600">My technical evolution over time</p>
        </div>

        <div ref={timelineRef} className="relative">
          {/* Timeline Line */}
          <div className="absolute left-1/2 transform -translate-x-0.5 w-1 h-full bg-gray-300"></div>

          {timelineData.map((item, index) => {
            const Icon = item.icon;
            const isVisible = visibleItems.has(index);
            const isEven = index % 2 === 0;

            return (
              <div
                key={index}
                data-index={index}
                className={`timeline-item relative mb-12 transition-all duration-700 ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
                }`}
                style={{ transitionDelay: `${index * 200}ms` }}
              >
                {/* Date Badge */}
                <div className="absolute left-1/2 transform -translate-x-1/2 -translate-y-1 z-10">
                  <div className={`px-4 py-2 rounded-full text-white font-semibold text-sm ${getColorClasses(item.color).split(' ')[0]}`}>
                    {item.date}
                  </div>
                </div>

                {/* Content Card */}
                <div className={`${isEven ? 'pr-1/2 mr-8' : 'pl-1/2 ml-8'} pt-8`}>
                  <div className={`bg-white p-6 rounded-xl shadow-lg border-l-4 ${getColorClasses(item.color).split(' ')[1]} hover:shadow-xl transition-shadow duration-300`}>
                    <div className="flex items-center mb-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center mr-3 ${getColorClasses(item.color).split(' ')[0]}`}>
                        <Icon className="w-5 h-5 text-white" />
                      </div>
                      <h3 className="text-xl font-bold text-gray-900">{item.title}</h3>
                    </div>
                    
                    <p className="text-gray-600 mb-4">{item.description}</p>
                    
                    <div className="flex flex-wrap gap-2">
                      {item.techs.map((tech) => (
                        <span
                          key={tech}
                          className={`px-3 py-1 rounded-full text-xs font-medium bg-gray-100 ${getColorClasses(item.color).split(' ')[2]}`}
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Timeline;