import React, { useState, useEffect } from 'react';
import { Eye, Download, Github, Linkedin, Mail } from 'lucide-react';
import Avatar from './Avatar';
import ParticleBackground from './ParticleBackground';

const Hero = () => {
  const [typedText, setTypedText] = useState('');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);
  
  const texts = ['Developer', 'Problem Solver', 'Innovator', 'Tech Enthusiast'];
  const currentText = texts[currentIndex];

  useEffect(() => {
    const timeout = setTimeout(() => {
      if (isDeleting) {
        setTypedText(currentText.substring(0, typedText.length - 1));
      } else {
        setTypedText(currentText.substring(0, typedText.length + 1));
      }

      if (!isDeleting && typedText === currentText) {
        setTimeout(() => setIsDeleting(true), 2000);
      } else if (isDeleting && typedText === '') {
        setIsDeleting(false);
        setCurrentIndex((currentIndex + 1) % texts.length);
      }
    }, isDeleting ? 50 : 100);

    return () => clearTimeout(timeout);
  }, [typedText, isDeleting, currentIndex, currentText]);

  const scrollToProjects = () => {
    document.getElementById('projects')?.scrollIntoView({ 
      behavior: 'smooth',
      block: 'start' 
    });
  };

  const downloadResume = () => {
    // Create resume content
    const resumeContent = `
SUDHANSHU SHARMA
Full Stack Developer

Email: sudhanshu.sharma.vs@gmail.com
LinkedIn: https://linkedin.com/in/sudhanshu-sharma-1745b8324
GitHub: https://github.com/SuDhAnShU-shr

TECHNICAL SKILLS:
- Frontend: HTML5, CSS3, JavaScript (ES6+)
- Backend: Python, C
- Database: DBMS, MongoDB
- DevOps: Docker, Kubernetes, Linux, AWS, Jenkins
- Framework: Flask
- Tools: Git, VS Code

PROJECTS:
1. Rajasthani Di Rasoi - Static website showcasing traditional cuisine
2. Public Toilet Locator App - React Native mobile application
3. Smart Portfolio Website - Interactive personal portfolio

CERTIFICATIONS:
- Voice of Leadership Anchoring – Pradyut Foundation
- Student Volunteer – One India, One World – LPU
- Linux Training Certificate

EDUCATION:
Currently pursuing studies with focus on software development

EXPERIENCE:
- Volunteer at LPU Event – 2025
- Multiple web development projects
- Continuous learning and skill development
    `;
    
    const blob = new Blob([resumeContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'CV_General_Sudhanshu.txt';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden bg-gradient-to-br from-blue-600 via-purple-600 to-blue-800">
      <ParticleBackground />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Avatar Section */}
          <div className="flex flex-col items-center lg:items-start space-y-8">
            <Avatar />
            <div className="bg-white/90 backdrop-blur-sm rounded-lg p-6 max-w-md text-center lg:text-left shadow-xl">
              <p className="text-gray-800 font-medium">
                Hi, I'm Sudhanshu 👋 I build smart solutions with code and creativity.
              </p>
            </div>
          </div>

          {/* Text Content */}
          <div className="text-white text-center lg:text-left">
            <h1 className="text-4xl lg:text-6xl font-bold mb-4">
              <span className="block mb-2">Sudhanshu Sharma</span>
              <span className="text-2xl lg:text-3xl text-yellow-300 font-medium">
                {typedText}
                <span className="animate-pulse">|</span>
              </span>
            </h1>
            
            <p className="text-xl lg:text-2xl mb-8 text-white/90 animate-fade-in-up delay-500">
              Building the future, one line of code at a time...
            </p>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <button
                onClick={scrollToProjects}
                className="flex items-center justify-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105 hover:shadow-lg"
              >
                <Eye className="w-5 h-5" />
                <span>View My Work</span>
              </button>
              <button
                onClick={downloadResume}
                className="flex items-center justify-center space-x-2 bg-transparent border-2 border-white text-white hover:bg-white hover:text-blue-600 px-8 py-3 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105"
              >
                <Download className="w-5 h-5" />
                <span>Download Resume</span>
              </button>
            </div>

            {/* Social Links */}
            <div className="flex justify-center lg:justify-start space-x-6">
              <a
                href="https://github.com/SuDhAnShU-shr"
                target="_blank"
                rel="noopener noreferrer"
                className="w-12 h-12 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white/20 transition-all duration-300 transform hover:scale-110"
              >
                <Github className="w-6 h-6" />
              </a>
              <a
                href="https://linkedin.com/in/sudhanshu-sharma-1745b8324"
                target="_blank"
                rel="noopener noreferrer"
                className="w-12 h-12 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white/20 transition-all duration-300 transform hover:scale-110"
              >
                <Linkedin className="w-6 h-6" />
              </a>
              <a
                href="mailto:sudhanshu.sharma.vs@gmail.com"
                className="w-12 h-12 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white/20 transition-all duration-300 transform hover:scale-110"
              >
                <Mail className="w-6 h-6" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;