import React, { useEffect, useRef, useState } from 'react';

const About = () => {
  const [statsVisible, setStatsVisible] = useState(false);
  const [projectsCount, setProjectsCount] = useState(0);
  const [techCount, setTechCount] = useState(0);
  const [coffeeCount, setCoffeeCount] = useState(0);
  const statsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !statsVisible) {
          setStatsVisible(true);
          animateCounter(setProjectsCount, 15);
          animateCounter(setTechCount, 7);
          animateCounter(setCoffeeCount, 100);
        }
      },
      { threshold: 0.5 }
    );

    if (statsRef.current) {
      observer.observe(statsRef.current);
    }

    return () => observer.disconnect();
  }, [statsVisible]);

  const animateCounter = (setter: React.Dispatch<React.SetStateAction<number>>, target: number) => {
    let current = 0;
    const increment = target / 50;
    const timer = setInterval(() => {
      current += increment;
      setter(Math.floor(current));
      if (current >= target) {
        setter(target);
        clearInterval(timer);
      }
    }, 40);
  };

  return (
    <section id="about" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">About Me</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Get to know the person behind the code
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-12 items-center">
          {/* Text Content */}
          <div className="lg:col-span-2 space-y-6">
            <p className="text-lg text-gray-700 leading-relaxed">
              I'm Sudhanshu Sharma — a developer who believes technology should solve real problems and make life better for everyone. My journey began with curiosity about how websites work, and it has evolved into a passion for creating innovative digital solutions.
            </p>
            
            <p className="text-lg text-gray-700 leading-relaxed">
              What sets me apart is my ability to bridge the gap between complex technical concepts and user-friendly interfaces. I approach every project with empathy, asking not just "How can I build this?" but "How can I build this better?"
            </p>
            
            <p className="text-lg text-gray-700 leading-relaxed">
              My goal is to work with forward-thinking companies where I can contribute to meaningful projects while continuously learning and growing. I'm particularly interested in roles that combine technical challenges with real-world impact.
            </p>

            <div className="flex flex-wrap gap-4 pt-6">
              <span className="px-4 py-2 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                Problem Solver
              </span>
              <span className="px-4 py-2 bg-green-100 text-green-800 rounded-full text-sm font-medium">
                Continuous Learner
              </span>
              <span className="px-4 py-2 bg-purple-100 text-purple-800 rounded-full text-sm font-medium">
                Team Player
              </span>
              <span className="px-4 py-2 bg-orange-100 text-orange-800 rounded-full text-sm font-medium">
                Innovation Focused
              </span>
            </div>
          </div>

          {/* Stats */}
          <div ref={statsRef} className="space-y-8">
            <div className="text-center p-6 bg-white rounded-xl shadow-lg transform hover:scale-105 transition-transform duration-300">
              <div className="text-4xl font-bold text-blue-600 mb-2">{projectsCount}+</div>
              <div className="text-gray-600 font-medium">Projects Completed</div>
            </div>
            
            <div className="text-center p-6 bg-white rounded-xl shadow-lg transform hover:scale-105 transition-transform duration-300">
              <div className="text-4xl font-bold text-green-600 mb-2">{techCount}+</div>
              <div className="text-gray-600 font-medium">Technologies Mastered</div>
            </div>
            
            <div className="text-center p-6 bg-white rounded-xl shadow-lg transform hover:scale-105 transition-transform duration-300">
              <div className="text-4xl font-bold text-orange-600 mb-2">{coffeeCount}+</div>
              <div className="text-gray-600 font-medium">Coffee Cups ☕</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;