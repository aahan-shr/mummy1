import React, { useState, useEffect } from 'react';
import { ArrowUp, Code, Coffee, Heart } from 'lucide-react';

const Footer = () => {
  const [currentQuote, setCurrentQuote] = useState(0);
  
  const quotes = [
    "Code is poetry written in logic.",
    "The best code is no code at all.",
    "Programming is thinking, not typing.",
    "Simplicity is the ultimate sophistication.",
    "Make it work, make it right, make it fast.",
    "First, solve the problem. Then, write the code.",
    "Code never lies, comments sometimes do.",
    "Any fool can write code that a computer can understand."
  ];

  const techStack = [
    { name: 'HTML5', icon: '🌐', color: 'text-orange-500' },
    { name: 'CSS3', icon: '🎨', color: 'text-blue-500' },
    { name: 'JavaScript', icon: '⚡', color: 'text-yellow-500' },
    { name: 'Python', icon: '🐍', color: 'text-green-500' },
    { name: 'Linux', icon: '🐧', color: 'text-gray-700' },
    { name: 'React', icon: '⚛️', color: 'text-blue-400' },
    { name: 'Node.js', icon: '🟢', color: 'text-green-600' },
    { name: 'Docker', icon: '🐳', color: 'text-blue-600' }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentQuote(prev => (prev + 1) % quotes.length);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-gray-900 text-white relative">
      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand & Quote */}
          <div className="lg:col-span-2">
            <h3 className="text-2xl font-bold mb-4">Sudhanshu Sharma</h3>
            <div className="mb-6">
              <div className="h-16 flex items-center">
                <p className="text-gray-300 italic text-lg transition-opacity duration-500">
                  "{quotes[currentQuote]}"
                </p>
              </div>
            </div>
            <p className="text-gray-400 leading-relaxed">
              A passionate full-stack developer dedicated to creating innovative solutions 
              that make a positive impact. Always learning, always growing, always coding.
            </p>
          </div>

          {/* Tech Stack */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Tech Stack</h4>
            <div className="grid grid-cols-2 gap-3">
              {techStack.map((tech) => (
                <div
                  key={tech.name}
                  className="flex items-center space-x-2 p-2 rounded-lg bg-gray-800 hover:bg-gray-700 transition-colors duration-200 cursor-pointer group"
                >
                  <span className="text-lg">{tech.icon}</span>
                  <span className={`text-sm font-medium ${tech.color} group-hover:text-white transition-colors duration-200`}>
                    {tech.name}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Links & Easter Egg Hint */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Explore</h4>
            <div className="space-y-3">
              <a href="#about" className="block text-gray-400 hover:text-white transition-colors duration-200">
                About Me
              </a>
              <a href="#skills" className="block text-gray-400 hover:text-white transition-colors duration-200">
                Skills
              </a>
              <a href="#projects" className="block text-gray-400 hover:text-white transition-colors duration-200">
                Projects
              </a>
              <a href="#contact" className="block text-gray-400 hover:text-white transition-colors duration-200">
                Contact
              </a>
            </div>
            
            <div className="mt-6 p-4 bg-blue-900/20 rounded-lg border border-blue-800">
              <div className="flex items-center space-x-2 mb-2">
                <span className="text-blue-400">💡</span>
                <span className="text-sm font-medium text-blue-300">Pro Tip</span>
              </div>
              <p className="text-xs text-blue-200">
                Try typing 'help' in terminal mode for hidden commands!
              </p>
            </div>
          </div>
        </div>

        {/* Stats Bar */}
        <div className="mt-12 pt-8 border-t border-gray-800">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 text-center">
            <div className="flex items-center justify-center space-x-3">
              <Code className="w-8 h-8 text-blue-400" />
              <div>
                <div className="text-2xl font-bold text-white">15+</div>
                <div className="text-sm text-gray-400">Projects Built</div>
              </div>
            </div>
            <div className="flex items-center justify-center space-x-3">
              <Coffee className="w-8 h-8 text-yellow-400" />
              <div>
                <div className="text-2xl font-bold text-white">∞</div>
                <div className="text-sm text-gray-400">Cups of Coffee</div>
              </div>
            </div>
            <div className="flex items-center justify-center space-x-3">
              <Heart className="w-8 h-8 text-red-400" />
              <div>
                <div className="text-2xl font-bold text-white">100%</div>
                <div className="text-sm text-gray-400">Passion Level</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-gray-800 bg-gray-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between">
            <div className="text-center sm:text-left mb-4 sm:mb-0">
              <p className="text-gray-400 text-sm">
                © 2025 Sudhanshu Sharma. Built with React & ❤️
              </p>
              <p className="text-gray-500 text-xs mt-1">
                Designed for performance, accessibility, and user experience
              </p>
            </div>
            
            <div className="flex items-center space-x-4">
              <span className="text-gray-500 text-xs">Made in India 🇮🇳</span>
              <button
                onClick={scrollToTop}
                className="flex items-center justify-center w-10 h-10 bg-blue-600 hover:bg-blue-700 rounded-full transition-colors duration-200 group"
                aria-label="Scroll to top"
              >
                <ArrowUp className="w-5 h-5 text-white group-hover:transform group-hover:-translate-y-1 transition-transform duration-200" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;