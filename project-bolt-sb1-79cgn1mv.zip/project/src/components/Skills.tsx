import React, { useState } from 'react';
import { Star } from 'lucide-react';

const Skills = () => {
  const [hoveredSkill, setHoveredSkill] = useState<string | null>(null);

  const skills = [
    {
      name: 'HTML',
      level: 5,
      since: 'Aug 2024',
      projects: '5+',
      description: 'Expert',
      icon: '🌐'
    },
    {
      name: 'CSS',
      level: 5,
      since: 'Aug 2024',
      projects: '5+',
      description: 'Expert',
      icon: '🎨'
    },
    {
      name: 'JavaScript',
      level: 4,
      since: 'Aug 2024',
      projects: '4+',
      description: 'Advanced',
      icon: '⚡'
    },
    {
      name: 'Python',
      level: 4,
      since: 'Oct 2024',
      projects: '3+',
      description: 'Advanced',
      icon: '🐍'
    },
    {
      name: 'C',
      level: 3,
      since: 'Feb 2025',
      projects: '2+',
      description: 'Intermediate',
      icon: '⚙️'
    },
    {
      name: 'Linux',
      level: 4,
      since: 'July 2025',
      projects: '2+',
      description: 'Advanced',
      icon: '🐧'
    },
    {
      name: 'DBMS',
      level: 3,
      since: 'Feb 2025',
      projects: '2+',
      description: 'Intermediate',
      icon: '🗄️'
    }
  ];

  const renderStars = (level: number) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Star
        key={index}
        className={`w-4 h-4 ${
          index < level ? 'text-yellow-400 fill-current' : 'text-gray-300'
        }`}
      />
    ));
  };

  return (
    <section id="skills" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Technical Skills</h2>
          <p className="text-xl text-gray-600">Technologies I work with</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {skills.map((skill) => (
            <div
              key={skill.name}
              className="relative bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 cursor-pointer"
              onMouseEnter={() => setHoveredSkill(skill.name)}
              onMouseLeave={() => setHoveredSkill(null)}
            >
              <div className="text-center">
                <div className="text-4xl mb-3">{skill.icon}</div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{skill.name}</h3>
                
                <div className="flex justify-center mb-3">
                  {renderStars(skill.level)}
                </div>

                <div className="text-sm text-gray-600">
                  {skill.description}
                </div>
              </div>

              {/* Tooltip */}
              {hoveredSkill === skill.name && (
                <div className="absolute -top-20 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white p-3 rounded-lg shadow-lg z-10 whitespace-nowrap">
                  <div className="text-sm">
                    <div><strong>Since:</strong> {skill.since}</div>
                    <div><strong>Projects:</strong> {skill.projects}</div>
                    <div><strong>Level:</strong> {skill.description}</div>
                  </div>
                  <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-4 border-transparent border-t-gray-900"></div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;