import React from 'react';
import { MapPin } from 'lucide-react';

const Map = () => {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Location</h2>
          <p className="text-xl text-gray-600">Find me here</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
          {/* Map */}
          <div className="lg:col-span-2">
            <div className="relative rounded-xl overflow-hidden shadow-lg">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3430.0446!2d75.7049!3d31.2428!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x391a5a5747a5a5a5%3A0x5a5a5a5a5a5a5a5!2sPhagwara%2C%20Punjab%2C%20India!5e0!3m2!1sen!2s!4v1234567890"
                width="100%"
                height="400"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="w-full h-96 lg:h-[400px]"
                title="Location Map"
              />
            </div>
          </div>

          {/* Location Info */}
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-xl shadow-lg border">
              <div className="flex items-center mb-4">
                <MapPin className="w-6 h-6 text-blue-600 mr-3" />
                <h3 className="text-xl font-bold text-gray-900">Current Location</h3>
              </div>
              <div className="space-y-3">
                <div>
                  <p className="text-gray-600 text-sm">City</p>
                  <p className="font-semibold text-gray-900">Phagwara, Punjab</p>
                </div>
                <div>
                  <p className="text-gray-600 text-sm">Country</p>
                  <p className="font-semibold text-gray-900">India</p>
                </div>
                <div>
                  <p className="text-gray-600 text-sm">Timezone</p>
                  <p className="font-semibold text-gray-900">IST (UTC+5:30)</p>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-purple-50 p-6 rounded-xl border border-blue-200">
              <div className="flex items-center mb-3">
                <span className="text-2xl mr-3">🏆</span>
                <h4 className="font-semibold text-gray-900">Achievement</h4>
              </div>
              <p className="text-gray-700 text-sm leading-relaxed">
                <strong>Volunteered at LPU Event – 2025</strong>
                <br />
                Contributed to the "One India, One World" initiative at Lovely Professional University, promoting cultural unity and diversity.
              </p>
            </div>

            <div className="bg-gray-50 p-6 rounded-xl">
              <h4 className="font-semibold text-gray-900 mb-3">Availability</h4>
              <div className="space-y-2 text-sm">
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
                  <span className="text-gray-700">Available for remote work</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-blue-500 rounded-full mr-3"></div>
                  <span className="text-gray-700">Open to relocation</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-purple-500 rounded-full mr-3"></div>
                  <span className="text-gray-700">Local opportunities welcome</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Map;