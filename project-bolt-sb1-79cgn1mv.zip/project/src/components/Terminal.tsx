import React, { useState, useEffect, useRef } from 'react';
import { X } from 'lucide-react';

const Terminal = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [output, setOutput] = useState<string[]>([
    'Welcome to Sudhanshu\'s Portfolio Terminal!',
    'Type "help" to see available commands.'
  ]);
  const [currentInput, setCurrentInput] = useState('');
  const [commandHistory, setCommandHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const inputRef = useRef<HTMLInputElement>(null);
  const outputRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        setIsOpen(false);
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen]);

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);

  useEffect(() => {
    if (outputRef.current) {
      outputRef.current.scrollTop = outputRef.current.scrollHeight;
    }
  }, [output]);

  const commands = {
    help: () => [
      'Available commands:',
      '',
      '  help              Show this help message',
      '  whoami           Display profile information',
      '  skills           List technical skills',
      '  show projects    Scroll to projects section',
      '  sudo hire me     Download resume with confetti 🎉',
      '  cd future        Display career aspirations',
      '  cat secrets.md   Show developer easter eggs',
      '  clear            Clear terminal screen',
      '  exit             Close terminal',
      '',
      'Navigation: ↑/↓ arrows for command history'
    ],
    
    whoami: () => [
      '╭─────────────────────────────────────────╮',
      '│              SUDHANSHU SHARMA           │',
      '│              Full Stack Developer      │',
      '╰─────────────────────────────────────────╯',
      '',
      'Name:           Sudhanshu Sharma',
      'Role:           Full Stack Developer',
      'Location:       Phagwara, Punjab, India',
      'Email:          sudhanshu.sharma.vs@gmail.com',
      'GitHub:         https://github.com/SuDhAnShU-shr',
      'LinkedIn:       linkedin.com/in/sudhanshu-sharma-1745b8324',
      '',
      'Status:         Available for opportunities',
      'Passion:        Building innovative solutions',
      'Motto:          "Code is poetry written in logic"'
    ],

    skills: () => [
      '╭─ TECHNICAL SKILLS ─────────────────────────╮',
      '',
      'Frontend Development:',
      '  ├─ HTML5        ★★★★★ (Expert)',
      '  ├─ CSS3         ★★★★★ (Expert)',
      '  └─ JavaScript   ★★★★☆ (Advanced)',
      '',
      'Backend Development:',
      '  ├─ Python       ★★★★☆ (Advanced)',
      '  └─ C            ★★★☆☆ (Intermediate)',
      '',
      'Database:',
      '  └─ DBMS         ★★★☆☆ (Intermediate)',
      '',
      'DevOps & Cloud:',
      '  ├─ Linux        ★★★★☆ (Advanced)',
      '  ├─ Docker       ★★★☆☆ (Intermediate)',
      '  ├─ Kubernetes   ★★☆☆☆ (Beginner)',
      '  └─ AWS          ★★☆☆☆ (Beginner)',
      '',
      'Total Experience: 1+ years of active development'
    ],

    'show projects': () => {
      const projectsSection = document.getElementById('projects');
      if (projectsSection) {
        projectsSection.scrollIntoView({ behavior: 'smooth' });
        setTimeout(() => {
          addOutput(['✅ Projects section displayed!']);
        }, 1000);
      }
      return ['Scrolling to projects section...'];
    },

    'sudo hire me': () => {
      // Create confetti effect
      createConfetti();
      
      // Download resume
      setTimeout(() => {
        const resumeContent = `
SUDHANSHU SHARMA - Full Stack Developer
Email: sudhanshu.sharma.vs@gmail.com
GitHub: https://github.com/SuDhAnShU-shr
LinkedIn: https://linkedin.com/in/sudhanshu-sharma-1745b8324

TECHNICAL SKILLS:
- Frontend: HTML5, CSS3, JavaScript
- Backend: Python, C
- Database: DBMS, MongoDB  
- DevOps: Docker, Kubernetes, Linux, AWS, Jenkins
- Framework: Flask

PROJECTS:
1. Rajasthani Di Rasoi - Cultural website
2. Public Toilet Locator App - React Native app
3. Smart Portfolio Website - This interactive portfolio

Ready to contribute to your team's success!
        `;
        
        const blob = new Blob([resumeContent], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'CV_General_Sudhanshu.txt';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
      }, 1500);

      return [
        '🎉 INITIATING HIRE SEQUENCE... 🎉',
        '',
        '┌─ SYSTEM CHECK ─┐',
        '├ Skills: ✅ Verified',
        '├ Passion: ✅ Maximum',
        '├ Availability: ✅ Ready',
        '└ Resume: ✅ Downloading...',
        '',
        '🎊 CONFETTI DEPLOYED! 🎊',
        '📄 Resume downloaded successfully!',
        '',
        'Thanks for considering me! Let\'s build something amazing together! 🚀'
      ];
    },

    'cd future': () => [
      '╭─ FUTURE ASPIRATIONS ──────────────────────╮',
      '',
      '🎯 SHORT TERM GOALS (6-12 months):',
      '   ├─ Land a full-stack developer position',
      '   ├─ Contribute to open-source projects',
      '   ├─ Master React.js and Node.js',
      '   └─ Build scalable web applications',
      '',
      '🚀 MEDIUM TERM GOALS (1-3 years):',
      '   ├─ Become a senior developer',
      '   ├─ Lead development teams',
      '   ├─ Architect complex systems',
      '   └─ Mentor junior developers',
      '',
      '🌟 LONG TERM VISION (3+ years):',
      '   ├─ Technical leadership roles',
      '   ├─ Create innovative products',
      '   ├─ Build my own tech startup',
      '   └─ Make a positive impact through technology',
      '',
      '"The future belongs to those who learn more skills and combine them in creative ways."'
    ],

    'cat secrets.md': () => [
      '╭─ DEVELOPER SECRETS ───────────────────────╮',
      '',
      '🤫 CONFESSION TIME:',
      '',
      '├─ I debug with console.log() more than I should admit',
      '├─ Stack Overflow is my second browser homepage',
      '├─ I\'ve spent 3 hours fixing a bug caused by a typo',
      '├─ Coffee is 60% of my development stack',
      '├─ I once tried to push to main on Friday evening',
      '├─ My code works, but I\'m not sure why (sometimes)',
      '└─ I have 47 browser tabs open right now',
      '',
      '🎭 EASTER EGGS:',
      '├─ This portfolio has hidden features (keep exploring!)',
      '├─ The particles follow your cursor (on desktop)',
      '├─ Try clicking my avatar multiple times',
      '└─ There\'s a konami code somewhere... 🎮',
      '',
      '💡 DEVELOPER WISDOM:',
      '"There are only 10 types of people in the world:',
      'those who understand binary and those who don\'t."',
      '',
      'Keep coding, keep learning, keep having fun! 🚀'
    ],

    clear: () => {
      setOutput([]);
      return [];
    },

    exit: () => {
      setIsOpen(false);
      return ['Terminal session ended.'];
    }
  };

  const createConfetti = () => {
    const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD'];
    const confettiContainer = document.createElement('div');
    confettiContainer.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 9999;
    `;
    document.body.appendChild(confettiContainer);

    for (let i = 0; i < 100; i++) {
      const confetti = document.createElement('div');
      confetti.style.cssText = `
        position: absolute;
        width: ${Math.random() * 10 + 5}px;
        height: ${Math.random() * 10 + 5}px;
        background: ${colors[Math.floor(Math.random() * colors.length)]};
        left: ${Math.random() * 100}%;
        top: -10px;
        border-radius: ${Math.random() > 0.5 ? '50%' : '0'};
        transform: rotate(${Math.random() * 360}deg);
        animation: confetti-fall ${Math.random() * 3 + 2}s linear forwards;
      `;
      confettiContainer.appendChild(confetti);
    }

    // Add CSS animation
    if (!document.getElementById('confetti-styles')) {
      const style = document.createElement('style');
      style.id = 'confetti-styles';
      style.textContent = `
        @keyframes confetti-fall {
          to {
            transform: translateY(100vh) rotate(720deg);
            opacity: 0;
          }
        }
      `;
      document.head.appendChild(style);
    }

    setTimeout(() => {
      document.body.removeChild(confettiContainer);
    }, 5000);
  };

  const addOutput = (lines: string[]) => {
    setOutput(prev => [...prev, ...lines]);
  };

  const executeCommand = (command: string) => {
    const trimmedCommand = command.trim().toLowerCase();
    
    if (trimmedCommand === '') return;

    // Add command to history
    setCommandHistory(prev => [...prev, command]);
    setHistoryIndex(-1);

    // Add command to output
    addOutput([`sudhanshu@portfolio:~$ ${command}`]);

    // Execute command
    if (commands[trimmedCommand as keyof typeof commands]) {
      const result = commands[trimmedCommand as keyof typeof commands]();
      if (result.length > 0) {
        addOutput(result);
      }
    } else {
      addOutput([`Command not found: ${command}. Type "help" for available commands.`]);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      executeCommand(currentInput);
      setCurrentInput('');
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (commandHistory.length > 0) {
        const newIndex = historyIndex === -1 ? commandHistory.length - 1 : Math.max(0, historyIndex - 1);
        setHistoryIndex(newIndex);
        setCurrentInput(commandHistory[newIndex] || '');
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIndex !== -1) {
        const newIndex = historyIndex + 1;
        if (newIndex < commandHistory.length) {
          setHistoryIndex(newIndex);
          setCurrentInput(commandHistory[newIndex]);
        } else {
          setHistoryIndex(-1);
          setCurrentInput('');
        }
      }
    }
  };

  useEffect(() => {
    const handleTerminalToggle = () => {
      setIsOpen(prev => !prev);
    };

    // Listen for terminal toggle from navbar
    document.addEventListener('terminal-toggle', handleTerminalToggle);
    return () => document.removeEventListener('terminal-toggle', handleTerminalToggle);
  }, []);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-50 p-4">
      <div className="w-full max-w-4xl h-3/4 bg-gray-900 rounded-lg overflow-hidden shadow-2xl">
        {/* Terminal Header */}
        <div className="bg-gray-800 px-4 py-2 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-red-500 rounded-full"></div>
            <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <span className="ml-4 text-gray-300 text-sm font-mono">sudhanshu@portfolio:~</span>
          </div>
          <button
            onClick={() => setIsOpen(false)}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Terminal Body */}
        <div className="h-full flex flex-col p-4 bg-black text-green-400 font-mono text-sm">
          {/* Output */}
          <div ref={outputRef} className="flex-1 overflow-y-auto mb-4 space-y-1">
            {output.map((line, index) => (
              <div key={index} className="whitespace-pre-wrap">
                {line}
              </div>
            ))}
          </div>

          {/* Input */}
          <div className="flex items-center">
            <span className="text-green-400 mr-2">sudhanshu@portfolio:~$</span>
            <input
              ref={inputRef}
              type="text"
              value={currentInput}
              onChange={(e) => setCurrentInput(e.target.value)}
              onKeyDown={handleKeyDown}
              className="flex-1 bg-transparent text-green-400 outline-none font-mono"
              autoComplete="off"
              spellCheck={false}
            />
            <span className="text-green-400 animate-pulse">|</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Terminal;