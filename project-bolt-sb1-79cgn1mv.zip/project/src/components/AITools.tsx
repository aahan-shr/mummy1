import React, { useState } from 'react';
import { FileText, Edit, Upload, Download, Copy, X } from 'lucide-react';

const AITools = () => {
  const [activeModal, setActiveModal] = useState<string | null>(null);
  const [resumeAnalysis, setResumeAnalysis] = useState<any>(null);
  const [coverLetter, setCoverLetter] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);

  const openModal = (modalId: string) => {
    setActiveModal(modalId);
  };

  const closeModal = () => {
    setActiveModal(null);
    setResumeAnalysis(null);
    setCoverLetter('');
  };

  const analyzeResume = async (file: File) => {
    setIsLoading(true);
    
    // Simulate AI analysis
    setTimeout(() => {
      const mockAnalysis = {
        score: Math.floor(Math.random() * 25) + 70, // 70-95
        missingKeywords: ['React', 'Node.js', 'TypeScript', 'AWS', 'Docker'].slice(0, Math.floor(Math.random() * 3) + 3),
        improvements: [
          'Add more quantifiable achievements',
          'Include specific project impact metrics',
          'Highlight leadership experience',
          'Strengthen technical skills section'
        ].slice(0, Math.floor(Math.random() * 2) + 2)
      };
      
      setResumeAnalysis(mockAnalysis);
      setIsLoading(false);
    }, 2000);
  };

  const generateCoverLetter = async (formData: FormData) => {
    setIsLoading(true);
    
    const company = formData.get('company') as string;
    const role = formData.get('role') as string;
    const notes = formData.get('notes') as string;

    setTimeout(() => {
      const letter = `Dear Hiring Manager,

I am writing to express my strong interest in the ${role} position at ${company}. As a passionate full-stack developer with a solid foundation in modern web technologies, I am excited about the opportunity to contribute to your team's success.

My technical journey includes expertise in HTML, CSS, JavaScript, Python, and C programming, along with experience in database management and DevOps technologies like Docker, Kubernetes, and AWS. This diverse skill set positions me well to tackle the challenges of the ${role} role.

What sets me apart is my ability to bridge the gap between complex technical concepts and user-friendly interfaces. I approach every project with empathy, asking not just "How can I build this?" but "How can I build this better?"

${notes ? `Additionally, ${notes.toLowerCase()}.` : ''}

I am particularly drawn to ${company} because of your commitment to innovation and excellence. I would welcome the opportunity to discuss how my technical skills and passion for problem-solving can contribute to your team.

Thank you for considering my application. I look forward to hearing from you.

Best regards,
Sudhanshu Sharma
sudhanshu.sharma.vs@gmail.com
LinkedIn: linkedin.com/in/sudhanshu-sharma-1745b8324
GitHub: github.com/SuDhAnShU-shr`;

      setCoverLetter(letter);
      setIsLoading(false);
    }, 1500);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(coverLetter);
    // Show success message
  };

  const downloadCoverLetter = () => {
    const blob = new Blob([coverLetter], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'Cover_Letter_Sudhanshu_Sharma.txt';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">AI-Powered Tools</h2>
          <p className="text-xl text-gray-600">Smart tools to enhance your workflow</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Resume Analyzer */}
          <div className="bg-white p-8 rounded-xl shadow-lg border hover:shadow-xl transition-shadow duration-300">
            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <FileText className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Resume Analyzer</h3>
              <p className="text-gray-600 mb-6">
                Upload your resume and get AI-powered insights and improvement suggestions.
              </p>
              <button
                onClick={() => openModal('resume-analyzer')}
                className="w-full bg-purple-600 hover:bg-purple-700 text-white py-3 px-6 rounded-lg font-semibold transition-colors duration-200 flex items-center justify-center space-x-2"
              >
                <Upload className="w-5 h-5" />
                <span>Analyze Resume</span>
              </button>
            </div>
          </div>

          {/* Cover Letter Generator */}
          <div className="bg-white p-8 rounded-xl shadow-lg border hover:shadow-xl transition-shadow duration-300">
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Edit className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Cover Letter Generator</h3>
              <p className="text-gray-600 mb-6">
                Generate personalized cover letters tailored to specific job applications.
              </p>
              <button
                onClick={() => openModal('cover-letter')}
                className="w-full bg-green-600 hover:bg-green-700 text-white py-3 px-6 rounded-lg font-semibold transition-colors duration-200 flex items-center justify-center space-x-2"
              >
                <Edit className="w-5 h-5" />
                <span>Generate Letter</span>
              </button>
            </div>
          </div>
        </div>

        {/* Resume Analyzer Modal */}
        {activeModal === 'resume-analyzer' && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6 border-b">
                <div className="flex items-center justify-between">
                  <h3 className="text-2xl font-bold text-gray-900">AI Resume Analyzer</h3>
                  <button onClick={closeModal} className="text-gray-500 hover:text-gray-700">
                    <X className="w-6 h-6" />
                  </button>
                </div>
              </div>
              
              <div className="p-6">
                {!resumeAnalysis && !isLoading && (
                  <div className="text-center">
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 hover:border-purple-400 transition-colors">
                      <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600 mb-4">Drag and drop your resume here or click to browse</p>
                      <input
                        type="file"
                        accept=".pdf,.docx"
                        onChange={(e) => e.target.files?.[0] && analyzeResume(e.target.files[0])}
                        className="hidden"
                        id="resume-upload"
                      />
                      <label
                        htmlFor="resume-upload"
                        className="bg-purple-600 hover:bg-purple-700 text-white py-2 px-4 rounded-lg cursor-pointer inline-block"
                      >
                        Browse Files
                      </label>
                    </div>
                  </div>
                )}

                {isLoading && (
                  <div className="text-center py-8">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
                    <p className="text-gray-600">Analyzing your resume...</p>
                  </div>
                )}

                {resumeAnalysis && (
                  <div className="space-y-6">
                    <div className="text-center">
                      <div className="w-24 h-24 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <span className="text-2xl font-bold text-purple-600">{resumeAnalysis.score}%</span>
                      </div>
                      <h4 className="text-xl font-bold text-gray-900 mb-2">Analysis Complete!</h4>
                    </div>

                    <div>
                      <h5 className="font-bold text-gray-900 mb-3">Missing Keywords:</h5>
                      <div className="flex flex-wrap gap-2">
                        {resumeAnalysis.missingKeywords.map((keyword: string) => (
                          <span key={keyword} className="px-3 py-1 bg-red-100 text-red-700 rounded-full text-sm">
                            {keyword}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h5 className="font-bold text-gray-900 mb-3">Improvements:</h5>
                      <ul className="space-y-2">
                        {resumeAnalysis.improvements.map((improvement: string, index: number) => (
                          <li key={index} className="flex items-start">
                            <span className="text-green-500 mr-2">•</span>
                            <span className="text-gray-700">{improvement}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Cover Letter Modal */}
        {activeModal === 'cover-letter' && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6 border-b">
                <div className="flex items-center justify-between">
                  <h3 className="text-2xl font-bold text-gray-900">Cover Letter Generator</h3>
                  <button onClick={closeModal} className="text-gray-500 hover:text-gray-700">
                    <X className="w-6 h-6" />
                  </button>
                </div>
              </div>
              
              <div className="p-6">
                {!coverLetter && !isLoading && (
                  <form onSubmit={(e) => { e.preventDefault(); generateCoverLetter(new FormData(e.target as HTMLFormElement)); }}>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Company Name *
                        </label>
                        <input
                          type="text"
                          name="company"
                          required
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Job Role *
                        </label>
                        <input
                          type="text"
                          name="role"
                          required
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Additional Notes
                        </label>
                        <textarea
                          name="notes"
                          rows={3}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        />
                      </div>
                      <button
                        type="submit"
                        className="w-full bg-green-600 hover:bg-green-700 text-white py-3 px-6 rounded-lg font-semibold transition-colors duration-200"
                      >
                        Generate Cover Letter
                      </button>
                    </div>
                  </form>
                )}

                {isLoading && (
                  <div className="text-center py-8">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
                    <p className="text-gray-600">Generating your cover letter...</p>
                  </div>
                )}

                {coverLetter && (
                  <div className="space-y-6">
                    <h4 className="text-xl font-bold text-gray-900">Generated Cover Letter</h4>
                    <div className="bg-gray-50 p-6 rounded-lg border">
                      <pre className="whitespace-pre-wrap text-sm text-gray-700 font-mono">
                        {coverLetter}
                      </pre>
                    </div>
                    <div className="flex space-x-4">
                      <button
                        onClick={copyToClipboard}
                        className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                      >
                        <Copy className="w-4 h-4" />
                        <span>Copy to Clipboard</span>
                      </button>
                      <button
                        onClick={downloadCoverLetter}
                        className="flex items-center space-x-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg"
                      >
                        <Download className="w-4 h-4" />
                        <span>Download</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default AITools;