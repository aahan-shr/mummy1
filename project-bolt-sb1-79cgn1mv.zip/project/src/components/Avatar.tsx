import React, { useState, useEffect } from 'react';

const Avatar = () => {
  const [isBlinking, setIsBlinking] = useState(false);
  const [eyePosition, setEyePosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    // Random blinking animation
    const blinkInterval = setInterval(() => {
      setIsBlinking(true);
      setTimeout(() => setIsBlinking(false), 150);
    }, 4000 + Math.random() * 2000);

    return () => clearInterval(blinkInterval);
  }, []);

  useEffect(() => {
    // Mouse tracking for eyes
    const handleMouseMove = (e: MouseEvent) => {
      const avatar = document.getElementById('avatar');
      if (!avatar) return;

      const rect = avatar.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;

      const angle = Math.atan2(e.clientY - centerY, e.clientX - centerX);
      const distance = Math.min(3, Math.sqrt(Math.pow(e.clientX - centerX, 2) + Math.pow(e.clientY - centerY, 2)) / 50);

      setEyePosition({
        x: Math.cos(angle) * distance,
        y: Math.sin(angle) * distance
      });
    };

    document.addEventListener('mousemove', handleMouseMove);
    return () => document.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <div 
      id="avatar"
      className="relative w-48 h-48 mx-auto animate-float"
    >
      {/* Avatar Container */}
      <div className="w-full h-full rounded-full bg-gradient-to-br from-blue-400 to-purple-500 p-2 animate-breathing">
        {/* Face */}
        <div className="w-full h-full rounded-full bg-yellow-100 relative overflow-hidden">
          {/* Eyes */}
          <div className="absolute top-16 left-1/2 transform -translate-x-1/2 flex space-x-5">
            <div className={`w-5 h-5 bg-gray-800 rounded-full transition-all duration-150 ${isBlinking ? 'h-1' : 'h-5'}`}>
              <div 
                className="w-2 h-2 bg-white rounded-full mt-0.5 ml-1.5 transition-transform duration-100"
                style={{
                  transform: `translate(${eyePosition.x}px, ${eyePosition.y}px)`
                }}
              />
            </div>
            <div className={`w-5 h-5 bg-gray-800 rounded-full transition-all duration-150 ${isBlinking ? 'h-1' : 'h-5'}`}>
              <div 
                className="w-2 h-2 bg-white rounded-full mt-0.5 ml-1.5 transition-transform duration-100"
                style={{
                  transform: `translate(${eyePosition.x}px, ${eyePosition.y}px)`
                }}
              />
            </div>
          </div>

          {/* Mouth */}
          <div className="absolute bottom-12 left-1/2 transform -translate-x-1/2">
            <div className="w-8 h-4 border-2 border-gray-800 border-t-0 rounded-b-full" />
          </div>

          {/* Hair */}
          <div className="absolute top-0 left-0 w-full h-8 bg-gray-800 rounded-t-full" />
        </div>
      </div>
    </div>
  );
};

export default Avatar;