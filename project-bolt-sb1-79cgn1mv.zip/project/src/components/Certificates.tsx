import React, { useState } from 'react';
import { X, Award } from 'lucide-react';

const Certificates = () => {
  const [selectedCert, setSelectedCert] = useState<string | null>(null);

  const certificates = [
    {
      id: 'leadership',
      title: 'Voice of Leadership Anchoring',
      organization: 'Pradyut Foundation',
      image: 'https://images.pexels.com/photos/267507/pexels-photo-267507.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'Leadership and communication skills certification'
    },
    {
      id: 'volunteer',
      title: 'Student Volunteer',
      organization: 'One India, One World – LPU',
      image: 'https://images.pexels.com/photos/6646918/pexels-photo-6646918.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'Volunteer work at university events'
    },
    {
      id: 'linux',
      title: 'Linux Training',
      organization: 'System Administration',
      image: 'https://images.pexels.com/photos/4164418/pexels-photo-4164418.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'Linux system administration and command line'
    }
  ];

  const openModal = (certId: string) => {
    setSelectedCert(certId);
  };

  const closeModal = () => {
    setSelectedCert(null);
  };

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Certifications</h2>
          <p className="text-xl text-gray-600">Professional achievements and recognitions</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {certificates.map((cert) => (
            <div
              key={cert.id}
              className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
            >
              <div className="h-48 overflow-hidden">
                <img
                  src={cert.image}
                  alt={cert.title}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center mb-3">
                  <Award className="w-5 h-5 text-yellow-500 mr-2" />
                  <h3 className="text-xl font-bold text-gray-900">{cert.title}</h3>
                </div>
                <p className="text-gray-600 mb-2 font-medium">{cert.organization}</p>
                <p className="text-gray-500 text-sm mb-4">{cert.description}</p>
                <button
                  onClick={() => openModal(cert.id)}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg font-semibold transition-colors duration-200"
                >
                  View Certificate
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Modal */}
        {selectedCert && (
          <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
            <div className="relative max-w-4xl max-h-[90vh] bg-white rounded-lg overflow-hidden">
              <button
                onClick={closeModal}
                className="absolute top-4 right-4 z-10 bg-black bg-opacity-50 text-white rounded-full p-2 hover:bg-opacity-70 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
              <img
                src={certificates.find(c => c.id === selectedCert)?.image}
                alt="Certificate"
                className="w-full h-full object-contain"
              />
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default Certificates;