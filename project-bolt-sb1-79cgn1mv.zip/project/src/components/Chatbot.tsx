import React, { useState, useEffect, useRef } from 'react';
import { MessageCircle, Send, X, Bot } from 'lucide-react';

interface Message {
  id: number;
  text: string;
  isBot: boolean;
  timestamp: Date;
}

const Chatbot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hi! I'm Sudhanshu's AI assistant. How can I help you today?",
      isBot: true,
      timestamp: new Date()
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const responses = {
    'hello': [
      "Hello! I'm here to help you learn more about Sudhanshu's skills and experience.",
      "Hi there! Feel free to ask me anything about Sudhanshu's work.",
      "Hello! Welcome to Sudhanshu's portfolio. What would you like to know?"
    ],
    'technologies': [
      "Sudhanshu works with HTML5, CSS3, JavaScript, Python, C, Linux, Docker, Kubernetes, AWS, Jenkins, Flask, and MongoDB. He's particularly strong in frontend development and expanding into DevOps.",
      "His tech stack includes frontend (HTML, CSS, JS), backend (Python, C), databases (DBMS, MongoDB), and cloud/DevOps tools (Linux, Docker, K8s, AWS, Jenkins)."
    ],
    'skills': [
      "Sudhanshu has strong skills in HTML, CSS, JavaScript, Python, and C programming. He's also experienced with Linux, databases, and DevOps tools like Docker and Kubernetes.",
      "His core skills include frontend development, Python programming, and system administration. Check out the skills section for detailed proficiency levels!"
    ],
    'projects': [
      "Sudhanshu has worked on several projects including Rajasthani Di Rasoi (a cultural website), a Public Toilet Locator App using React Native, and this interactive portfolio website with AI features!",
      "You can see his projects in the portfolio section above! Each project demonstrates different technical skills and problem-solving approaches."
    ],
    'experience': [
      "Sudhanshu has been actively developing for over a year, completing 15+ projects and continuously learning new technologies. He started with web fundamentals and has progressed to full-stack development.",
      "With 1+ years of hands-on development experience, Sudhanshu has built a strong foundation in multiple technologies while maintaining focus on practical, real-world applications."
    ],
    'contact': [
      "You can reach Sudhanshu at sudhanshu.sharma.vs@gmail.com or connect on LinkedIn at linkedin.com/in/sudhanshu-sharma-1745b8324. He's also active on GitHub!",
      "Contact information: Email - sudhanshu.sharma.vs@gmail.com, LinkedIn - sudhanshu-sharma-1745b8324, GitHub - SuDhAnShU-shr. He typically responds within 24 hours!"
    ],
    'hire': [
      "Sudhanshu is actively seeking opportunities! He's passionate about building innovative solutions and would love to contribute to your team. Contact him to discuss how he can help!",
      "Absolutely! Sudhanshu is looking for roles where he can apply his technical skills while continuing to grow. Reach out to discuss potential opportunities!"
    ]
  };

  const defaultResponses = [
    "That's interesting! Tell me more about what you'd like to know about Sudhanshu.",
    "I'm here to help! You can ask me about Sudhanshu's skills, projects, or experience.",
    "Feel free to ask me anything about Sudhanshu's technical background or career goals.",
    "I'd be happy to help! Try asking about technologies, projects, or how to get in touch."
  ];

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const generateResponse = (userInput: string): string => {
    const input = userInput.toLowerCase();
    
    for (const [keyword, responseList] of Object.entries(responses)) {
      if (input.includes(keyword)) {
        return responseList[Math.floor(Math.random() * responseList.length)];
      }
    }
    
    return defaultResponses[Math.floor(Math.random() * defaultResponses.length)];
  };

  const handleSendMessage = () => {
    if (!inputText.trim()) return;

    const userMessage: Message = {
      id: messages.length + 1,
      text: inputText,
      isBot: false,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsTyping(true);

    // Simulate bot thinking time
    setTimeout(() => {
      const botResponse: Message = {
        id: messages.length + 2,
        text: generateResponse(inputText),
        isBot: true,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Chatbot Toggle Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="w-14 h-14 bg-blue-600 hover:bg-blue-700 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center group animate-pulse"
        >
          <MessageCircle className="w-6 h-6 group-hover:scale-110 transition-transform duration-200" />
        </button>
      )}

      {/* Chatbot Window */}
      {isOpen && (
        <div className="w-80 h-96 bg-white rounded-lg shadow-2xl border border-gray-200 flex flex-col overflow-hidden">
          {/* Header */}
          <div className="bg-blue-600 text-white p-4 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                <Bot className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-semibold">AI Assistant</h4>
                <p className="text-xs text-blue-100">Ask me anything!</p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-blue-100 hover:text-white transition-colors duration-200"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.isBot ? 'justify-start' : 'justify-end'}`}
              >
                <div
                  className={`max-w-xs px-4 py-2 rounded-lg ${
                    message.isBot
                      ? 'bg-white text-gray-800 border border-gray-200'
                      : 'bg-blue-600 text-white'
                  }`}
                >
                  <p className="text-sm">{message.text}</p>
                </div>
              </div>
            ))}
            
            {/* Typing Indicator */}
            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-white border border-gray-200 px-4 py-2 rounded-lg">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t border-gray-200 bg-white">
            <div className="flex space-x-2">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Type your message..."
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
              />
              <button
                onClick={handleSendMessage}
                disabled={!inputText.trim()}
                className={`px-3 py-2 rounded-lg transition-colors duration-200 ${
                  inputText.trim()
                    ? 'bg-blue-600 hover:bg-blue-700 text-white'
                    : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                }`}
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Chatbot;