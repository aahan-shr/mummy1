import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Timeline from './components/Timeline';
import Skills from './components/Skills';
import Certificates from './components/Certificates';
import Projects from './components/Projects';
import AITools from './components/AITools';
import DevTools from './components/DevTools';
import Map from './components/Map';
import Contact from './components/Contact';
import Footer from './components/Footer';
import Terminal from './components/Terminal';
import Chatbot from './components/Chatbot';
import ScrollToTop from './components/ScrollToTop';
import WhatsAppButton from './components/WhatsAppButton';
import TechJourneyCards from './components/TechJourneyCards';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <Hero />
      <About />
      <Timeline />
      <Skills />
      <Certificates />
      <Projects />
      <AITools />
      <DevTools />
      <TechJourneyCards />
      <Map />
      <Contact />
      <Footer />
      <Terminal />
      <Chatbot />
      <ScrollToTop />
      <WhatsAppButton />
    </div>
  );
}

export default App;