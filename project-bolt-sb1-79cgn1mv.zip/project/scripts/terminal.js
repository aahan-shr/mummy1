// Terminal functionality
class Terminal {
    constructor() {
        this.overlay = document.getElementById('terminal-overlay');
        this.output = document.getElementById('terminal-output');
        this.input = document.getElementById('terminal-input');
        this.closeBtn = document.getElementById('terminal-close');
        this.toggleBtn = document.getElementById('terminal-toggle');
        
        this.commandHistory = [];
        this.historyIndex = -1;
        this.currentPath = '~';
        
        this.commands = {
            help: this.showHelp.bind(this),
            whoami: this.showProfile.bind(this),
            skills: this.showSkills.bind(this),
            'show projects': this.showProjects.bind(this),
            projects: this.showProjects.bind(this),
            'sudo hire me': this.hireMe.bind(this),
            'cd future': this.showFuture.bind(this),
            'cat secrets.md': this.showSecrets.bind(this),
            clear: this.clear.bind(this),
            pwd: this.pwd.bind(this),
            ls: this.ls.bind(this),
            date: this.date.bind(this),
            echo: this.echo.bind(this),
            contact: this.showContact.bind(this),
            about: this.showAbout.bind(this),
            exit: this.close.bind(this)
        };
        
        this.initialize();
    }
    
    initialize() {
        if (!this.overlay || !this.input) return;
        
        // Toggle terminal
        if (this.toggleBtn) {
            this.toggleBtn.addEventListener('click', () => this.open());
        }
        
        // Close terminal
        if (this.closeBtn) {
            this.closeBtn.addEventListener('click', () => this.close());
        }
        
        // Close on escape
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.overlay.classList.contains('show')) {
                this.close();
            }
        });
        
        // Handle input
        this.input.addEventListener('keydown', (e) => {
            this.handleKeydown(e);
        });
        
        // Focus input when terminal is open
        this.overlay.addEventListener('click', (e) => {
            if (e.target === this.overlay) {
                this.input.focus();
            }
        });
    }
    
    open() {
        this.overlay.classList.add('show');
        this.input.focus();
        this.addLine('Terminal session started. Type "help" for available commands.');
    }
    
    close() {
        this.overlay.classList.remove('show');
    }
    
    handleKeydown(e) {
        switch (e.key) {
            case 'Enter':
                e.preventDefault();
                this.executeCommand();
                break;
            case 'ArrowUp':
                e.preventDefault();
                this.navigateHistory(-1);
                break;
            case 'ArrowDown':
                e.preventDefault();
                this.navigateHistory(1);
                break;
            case 'Tab':
                e.preventDefault();
                this.autocomplete();
                break;
            case 'c':
                if (e.ctrlKey) {
                    e.preventDefault();
                    this.addLine('^C');
                    this.input.value = '';
                }
                break;
        }
    }
    
    executeCommand() {
        const command = this.input.value.trim();
        if (!command) return;
        
        // Add to history
        this.commandHistory.push(command);
        this.historyIndex = this.commandHistory.length;
        
        // Show command in output
        this.addLine(`sudhanshu@portfolio:${this.currentPath}$ ${command}`, 'command');
        
        // Execute command
        const args = command.split(' ');
        const cmd = args[0].toLowerCase();
        const fullCommand = command.toLowerCase();
        
        if (this.commands[fullCommand]) {
            this.commands[fullCommand](args.slice(1));
        } else if (this.commands[cmd]) {
            this.commands[cmd](args.slice(1));
        } else {
            this.addLine(`Command not found: ${cmd}. Type "help" for available commands.`, 'error');
        }
        
        // Clear input
        this.input.value = '';
        
        // Scroll to bottom
        this.output.scrollTop = this.output.scrollHeight;
    }
    
    navigateHistory(direction) {
        const newIndex = this.historyIndex + direction;
        
        if (newIndex >= 0 && newIndex < this.commandHistory.length) {
            this.historyIndex = newIndex;
            this.input.value = this.commandHistory[this.historyIndex];
        } else if (newIndex === this.commandHistory.length) {
            this.historyIndex = newIndex;
            this.input.value = '';
        }
    }
    
    autocomplete() {
        const input = this.input.value.toLowerCase();
        const matches = Object.keys(this.commands).filter(cmd => cmd.startsWith(input));
        
        if (matches.length === 1) {
            this.input.value = matches[0];
        } else if (matches.length > 1) {
            this.addLine('Available commands:');
            matches.forEach(match => {
                this.addLine(`  ${match}`);
            });
        }
    }
    
    addLine(text, type = 'output') {
        const line = document.createElement('div');
        line.className = `terminal-line ${type}`;
        
        if (type === 'command') {
            line.innerHTML = `<span class="terminal-prompt">sudhanshu@portfolio:${this.currentPath}$</span> <span class="terminal-text">${text.replace(/^[^$]*\$ /, '')}</span>`;
        } else {
            line.innerHTML = `<span class="terminal-text ${type}">${text}</span>`;
        }
        
        this.output.appendChild(line);
        this.output.scrollTop = this.output.scrollHeight;
    }
    
    // Command implementations
    showHelp() {
        const helpText = `
Available commands:

  help                 Show this help message
  whoami              Display profile information
  skills              List technical skills and proficiency
  projects            Show featured projects
  show projects       Scroll to projects section
  sudo hire me        Download resume with confetti 🎉
  cd future           Display career aspirations
  cat secrets.md      Show developer easter eggs
  contact             Display contact information
  about               Show brief bio
  clear               Clear terminal screen
  pwd                 Show current directory
  ls                  List directory contents
  date                Show current date and time
  echo [text]         Echo text back
  exit                Close terminal

Navigation:
  ↑/↓ arrows         Navigate command history
  Tab                Autocomplete commands
  Ctrl+C             Cancel current command
  Esc                Close terminal

Tip: Try typing "sudo hire me" for a surprise! ✨
        `;
        this.addLine(helpText.trim());
    }
    
    showProfile() {
        const profile = `
╭─────────────────────────────────────────╮
│              SUDHANSHU SHARMA           │
│              Full Stack Developer      │
╰─────────────────────────────────────────╯

Name:           Sudhanshu Sharma
Role:           Full Stack Developer
Location:       Phagwara, Punjab, India
Email:          sudhanshu.sharma.vs@gmail.com
GitHub:         https://github.com/SuDhAnShU-shr
LinkedIn:       linkedin.com/in/sudhanshu-sharma-1745b8324

Status:         Available for opportunities
Passion:        Building innovative solutions
Motto:          "Code is poetry written in logic"

Learning Journey:
├─ Aug 2024: Started with HTML, CSS, JavaScript
├─ Oct 2024: Mastered Python programming
├─ Feb 2025: Learned C and Database Management
└─ Jul 2025: Explored DevOps with Docker, K8s, AWS
        `;
        this.addLine(profile.trim());
    }
    
    showSkills() {
        const skills = `
╭─ TECHNICAL SKILLS ─────────────────────────╮

Frontend Development:
  ├─ HTML5        ★★★★★ (Expert)
  ├─ CSS3         ★★★★★ (Expert) 
  └─ JavaScript   ★★★★☆ (Advanced)

Backend Development:
  ├─ Python       ★★★★☆ (Advanced)
  └─ C            ★★★☆☆ (Intermediate)

Database:
  └─ DBMS         ★★★☆☆ (Intermediate)

DevOps & Cloud:
  ├─ Linux        ★★★★☆ (Advanced)
  ├─ Docker       ★★★☆☆ (Intermediate)
  ├─ Kubernetes   ★★☆☆☆ (Beginner)
  ├─ AWS          ★★☆☆☆ (Beginner)
  └─ Jenkins      ★★☆☆☆ (Beginner)

Frameworks:
  ├─ Flask        ★★★☆☆ (Intermediate)
  └─ MongoDB      ★★☆☆☆ (Beginner)

Total Experience: 1+ years of active development
Projects Completed: 15+
        `;
        this.addLine(skills.trim());
    }
    
    showProjects() {
        const projectsSection = document.getElementById('projects');
        if (projectsSection) {
            projectsSection.scrollIntoView({ behavior: 'smooth' });
            this.addLine('Scrolling to projects section...');
            setTimeout(() => {
                this.addLine('✅ Projects section displayed!');
            }, 1000);
        } else {
            this.showProjectsList();
        }
    }
    
    showProjectsList() {
        const projects = `
╭─ FEATURED PROJECTS ───────────────────────╮

1. 🍛 Rajasthani Di Rasoi
   ├─ Type: Static Website
   ├─ Tech: HTML, CSS, JavaScript
   ├─ Desc: Traditional Rajasthani cuisine showcase
   └─ Status: Completed

2. 🚻 Public Toilet Locator App  
   ├─ Type: Mobile Application
   ├─ Tech: React Native, Firebase, Maps API
   ├─ Desc: Real-time toilet location finder
   └─ Status: In Development

3. 💼 Smart Portfolio Website
   ├─ Type: Interactive Portfolio
   ├─ Tech: HTML, CSS, JavaScript, AI Tools
   ├─ Desc: This very website you're viewing!
   └─ Status: Live & Evolving

View live demos and source code in the projects section above!
        `;
        this.addLine(projects.trim());
    }
    
    hireMe() {
        this.addLine('🎉 INITIATING HIRE SEQUENCE... 🎉');
        this.addLine('');
        this.addLine('┌─ SYSTEM CHECK ─┐');
        this.addLine('├ Skills: ✅ Verified');
        this.addLine('├ Passion: ✅ Maximum');
        this.addLine('├ Availability: ✅ Ready');
        this.addLine('└ Resume: ✅ Downloading...');
        this.addLine('');
        
        // Trigger confetti
        this.createConfetti();
        
        // Download resume
        setTimeout(() => {
            const downloadBtn = document.getElementById('download-resume-btn');
            if (downloadBtn) {
                downloadBtn.click();
            }
            this.addLine('🎊 CONFETTI DEPLOYED! 🎊');
            this.addLine('📄 Resume downloaded successfully!');
            this.addLine('');
            this.addLine('Thanks for considering me! Let\'s build something amazing together! 🚀');
        }, 1500);
    }
    
    createConfetti() {
        const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD'];
        const confettiContainer = document.createElement('div');
        confettiContainer.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 9999;
        `;
        document.body.appendChild(confettiContainer);
        
        for (let i = 0; i < 100; i++) {
            const confetti = document.createElement('div');
            confetti.style.cssText = `
                position: absolute;
                width: ${Math.random() * 10 + 5}px;
                height: ${Math.random() * 10 + 5}px;
                background: ${colors[Math.floor(Math.random() * colors.length)]};
                left: ${Math.random() * 100}%;
                top: -10px;
                border-radius: ${Math.random() > 0.5 ? '50%' : '0'};
                transform: rotate(${Math.random() * 360}deg);
                animation: confetti-fall ${Math.random() * 3 + 2}s linear forwards;
            `;
            confettiContainer.appendChild(confetti);
        }
        
        // Add confetti animation if not exists
        if (!document.getElementById('confetti-styles')) {
            const style = document.createElement('style');
            style.id = 'confetti-styles';
            style.textContent = `
                @keyframes confetti-fall {
                    to {
                        transform: translateY(100vh) rotate(720deg);
                        opacity: 0;
                    }
                }
            `;
            document.head.appendChild(style);
        }
        
        setTimeout(() => {
            document.body.removeChild(confettiContainer);
        }, 5000);
    }
    
    showFuture() {
        const future = `
╭─ FUTURE ASPIRATIONS ──────────────────────╮

🎯 SHORT TERM GOALS (6-12 months):
   ├─ Land a full-stack developer position
   ├─ Contribute to open-source projects
   ├─ Master React.js and Node.js
   └─ Build scalable web applications

🚀 MEDIUM TERM GOALS (1-3 years):
   ├─ Become a senior developer
   ├─ Lead development teams
   ├─ Architect complex systems
   └─ Mentor junior developers

🌟 LONG TERM VISION (3+ years):
   ├─ Technical leadership roles
   ├─ Create innovative products
   ├─ Build my own tech startup
   └─ Make a positive impact through technology

💡 CORE VALUES:
   ├─ Continuous learning and growth
   ├─ Writing clean, maintainable code
   ├─ Solving real-world problems
   └─ Collaborating with amazing teams

"The future belongs to those who learn more skills and combine them in creative ways." - Robert Greene
        `;
        this.addLine(future.trim());
    }
    
    showSecrets() {
        const secrets = `
╭─ DEVELOPER SECRETS ───────────────────────╮

🤫 CONFESSION TIME:

├─ I debug with console.log() more than I should admit
├─ Stack Overflow is my second browser homepage  
├─ I've spent 3 hours fixing a bug caused by a typo
├─ Coffee is 60% of my development stack
├─ I once tried to push to main on Friday evening
├─ My code works, but I'm not sure why (sometimes)
├─ I have 47 browser tabs open right now
└─ I still Google "center a div" occasionally

🎭 EASTER EGGS:
├─ This portfolio has a Konami code (try it!)
├─ Click my avatar 10 times for a surprise
├─ The particles follow your cursor (on desktop)
└─ There's a hidden Rick Roll somewhere... 🎵

🔮 DEVELOPER WISDOM:
"There are only 10 types of people in the world:
those who understand binary and those who don't."

99 little bugs in the code,
99 little bugs.
Take one down, patch it around,
127 little bugs in the code...

Keep coding, keep learning, keep having fun! 🚀
        `;
        this.addLine(secrets.trim());
    }
    
    showContact() {
        const contact = `
╭─ CONTACT INFORMATION ─────────────────────╮

📧 Email:    sudhanshu.sharma.vs@gmail.com
🔗 LinkedIn: linkedin.com/in/sudhanshu-sharma-1745b8324  
🐙 GitHub:   github.com/SuDhAnShU-shr
📱 WhatsApp: Available via contact form
📍 Location: Phagwara, Punjab, India

💬 PREFERRED CONTACT METHODS:
├─ Email (Professional inquiries)
├─ LinkedIn (Networking & opportunities)  
├─ GitHub (Code collaboration)
└─ Contact form on this website

⚡ RESPONSE TIME:
├─ Email: Within 24 hours
├─ LinkedIn: Within 48 hours
└─ GitHub: Within 72 hours

Feel free to reach out for:
• Job opportunities
• Collaboration on projects  
• Technical discussions
• Mentorship questions
• Just to say hello! 👋
        `;
        this.addLine(contact.trim());
    }
    
    showAbout() {
        const about = `
╭─ ABOUT SUDHANSHU ─────────────────────────╮

Hello! I'm Sudhanshu Sharma, a passionate full-stack developer 
who believes technology should solve real problems and make 
life better for everyone.

🌱 MY JOURNEY:
Started with curiosity about how websites work, evolved into 
a passion for creating innovative digital solutions.

💡 WHAT SETS ME APART:
Ability to bridge the gap between complex technical concepts 
and user-friendly interfaces. I approach every project with 
empathy, asking not just "How can I build this?" but 
"How can I build this better?"

🎯 CURRENT FOCUS:
Working with forward-thinking companies where I can contribute 
to meaningful projects while continuously learning and growing.

🔥 INTERESTS:
• Clean, maintainable code
• User experience design  
• Problem-solving through technology
• Open source contributions
• Continuous learning

"Code is poetry written in logic" - that's my motto! ✨
        `;
        this.addLine(about.trim());
    }
    
    clear() {
        this.output.innerHTML = '';
        this.addLine('Terminal cleared.');
    }
    
    pwd() {
        this.addLine(`/home/sudhanshu${this.currentPath === '~' ? '' : this.currentPath}`);
    }
    
    ls() {
        const files = `
total 42
drwxr-xr-x  8 sudhanshu  staff   256B  ${new Date().toLocaleDateString()}  .
drwxr-xr-x  3 root       wheel    96B  ${new Date().toLocaleDateString()}  ..
-rw-r--r--  1 sudhanshu  staff   1.2K  ${new Date().toLocaleDateString()}  .bashrc
-rw-r--r--  1 sudhanshu  staff   2.4K  ${new Date().toLocaleDateString()}  README.md
drwxr-xr-x  5 sudhanshu  staff   160B  ${new Date().toLocaleDateString()}  projects/
-rw-r--r--  1 sudhanshu  staff   156K  ${new Date().toLocaleDateString()}  resume.pdf
-rw-r--r--  1 sudhanshu  staff   892B  ${new Date().toLocaleDateString()}  secrets.md
drwxr-xr-x  3 sudhanshu  staff    96B  ${new Date().toLocaleDateString()}  skills/
        `;
        this.addLine(files.trim());
    }
    
    date() {
        const now = new Date();
        this.addLine(now.toString());
    }
    
    echo(args) {
        this.addLine(args.join(' '));
    }
}

// Initialize terminal when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.terminal = new Terminal();
});