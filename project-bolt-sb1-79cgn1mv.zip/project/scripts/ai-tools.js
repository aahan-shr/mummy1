// AI Tools functionality
class AITools {
    constructor() {
        this.initializeResumeAnalyzer();
        this.initializeCoverLetterGenerator();
    }
    
    initializeResumeAnalyzer() {
        const openBtns = document.querySelectorAll('[data-tool="resume-analyzer"]');
        const modal = document.getElementById('resume-analyzer-modal');
        const uploadArea = document.getElementById('upload-area');
        const fileInput = document.getElementById('resume-file');
        const browseBtn = document.getElementById('browse-btn');
        const analysisResult = document.getElementById('analysis-result');
        
        if (!modal) return;
        
        // Open modal
        openBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                modal.classList.add('show');
                this.resetResumeAnalyzer();
            });
        });
        
        // Browse button
        if (browseBtn && fileInput) {
            browseBtn.addEventListener('click', () => {
                fileInput.click();
            });
        }
        
        // File input change
        if (fileInput) {
            fileInput.addEventListener('change', (e) => {
                if (e.target.files.length > 0) {
                    this.analyzeResume(e.target.files[0]);
                }
            });
        }
        
        // Drag and drop
        if (uploadArea) {
            uploadArea.addEventListener('dragover', (e) => {
                e.preventDefault();
                uploadArea.classList.add('dragover');
            });
            
            uploadArea.addEventListener('dragleave', () => {
                uploadArea.classList.remove('dragover');
            });
            
            uploadArea.addEventListener('drop', (e) => {
                e.preventDefault();
                uploadArea.classList.remove('dragover');
                
                const files = e.dataTransfer.files;
                if (files.length > 0) {
                    this.analyzeResume(files[0]);
                }
            });
        }
    }
    
    analyzeResume(file) {
        const uploadArea = document.getElementById('upload-area');
        const analysisResult = document.getElementById('analysis-result');
        
        // Validate file
        if (!this.validateResumeFile(file)) {
            return;
        }
        
        // Show loading state
        uploadArea.style.display = 'none';
        
        // Simulate analysis (2-3 seconds)
        setTimeout(() => {
            const analysis = this.generateResumeAnalysis();
            this.displayResumeAnalysis(analysis);
            analysisResult.style.display = 'block';
        }, 2000 + Math.random() * 1000);
    }
    
    validateResumeFile(file) {
        const maxSize = 5 * 1024 * 1024; // 5MB
        const allowedTypes = ['application/pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
        
        if (file.size > maxSize) {
            this.showError('File size must be less than 5MB');
            return false;
        }
        
        if (!allowedTypes.includes(file.type)) {
            this.showError('Please upload a PDF or DOCX file');
            return false;
        }
        
        return true;
    }
    
    generateResumeAnalysis() {
        const scores = [75, 82, 88, 91, 85, 79, 93];
        const score = scores[Math.floor(Math.random() * scores.length)];
        
        const keywordSets = [
            ['React', 'Node.js', 'TypeScript', 'AWS', 'Docker'],
            ['Vue.js', 'Express', 'MongoDB', 'Redis', 'CI/CD'],
            ['Angular', 'Python', 'PostgreSQL', 'Kubernetes', 'Git'],
            ['Next.js', 'GraphQL', 'MySQL', 'Jenkins', 'Agile']
        ];
        
        const improvementSets = [
            ['Add more quantifiable achievements', 'Include specific project impact metrics', 'Highlight leadership experience'],
            ['Strengthen technical skills section', 'Add relevant certifications', 'Include soft skills examples'],
            ['Improve formatting consistency', 'Add action verbs to descriptions', 'Include volunteer work'],
            ['Expand on problem-solving examples', 'Add team collaboration details', 'Include learning initiatives']
        ];
        
        const missingKeywords = keywordSets[Math.floor(Math.random() * keywordSets.length)];
        const improvements = improvementSets[Math.floor(Math.random() * improvementSets.length)];
        
        return {
            score,
            missingKeywords: missingKeywords.slice(0, 3 + Math.floor(Math.random() * 3)),
            improvements: improvements.slice(0, 2 + Math.floor(Math.random() * 2))
        };
    }
    
    displayResumeAnalysis(analysis) {
        const scoreElement = document.getElementById('resume-score');
        const keywordsElement = document.getElementById('missing-keywords');
        const improvementsElement = document.getElementById('improvements');
        
        if (scoreElement) {
            this.animateScore(scoreElement, analysis.score);
        }
        
        if (keywordsElement) {
            keywordsElement.innerHTML = analysis.missingKeywords
                .map(keyword => `<li>• ${keyword}</li>`)
                .join('');
        }
        
        if (improvementsElement) {
            improvementsElement.innerHTML = analysis.improvements
                .map(improvement => `<li>• ${improvement}</li>`)
                .join('');
        }
    }
    
    animateScore(element, targetScore) {
        let currentScore = 0;
        const increment = targetScore / 50;
        
        const animation = setInterval(() => {
            currentScore += increment;
            element.textContent = Math.floor(currentScore);
            
            if (currentScore >= targetScore) {
                element.textContent = targetScore;
                clearInterval(animation);
            }
        }, 50);
    }
    
    resetResumeAnalyzer() {
        const uploadArea = document.getElementById('upload-area');
        const analysisResult = document.getElementById('analysis-result');
        const fileInput = document.getElementById('resume-file');
        
        if (uploadArea) uploadArea.style.display = 'block';
        if (analysisResult) analysisResult.style.display = 'none';
        if (fileInput) fileInput.value = '';
    }
    
    initializeCoverLetterGenerator() {
        const openBtns = document.querySelectorAll('[data-tool="cover-letter"]');
        const modal = document.getElementById('cover-letter-modal');
        const form = document.getElementById('cover-letter-form');
        const result = document.getElementById('cover-letter-result');
        const copyBtn = document.getElementById('copy-letter');
        const downloadBtn = document.getElementById('download-letter');
        
        if (!modal || !form) return;
        
        // Open modal
        openBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                modal.classList.add('show');
                this.resetCoverLetterGenerator();
            });
        });
        
        // Form submission
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            this.generateCoverLetter();
        });
        
        // Copy functionality
        if (copyBtn) {
            copyBtn.addEventListener('click', () => {
                this.copyCoverLetter();
            });
        }
        
        // Download functionality
        if (downloadBtn) {
            downloadBtn.addEventListener('click', () => {
                this.downloadCoverLetter();
            });
        }
    }
    
    generateCoverLetter() {
        const form = document.getElementById('cover-letter-form');
        const result = document.getElementById('cover-letter-result');
        const formData = new FormData(form);
        
        const companyName = formData.get('company-name');
        const jobRole = formData.get('job-role');
        const additionalNotes = formData.get('additional-notes') || '';
        
        if (!companyName || !jobRole) {
            this.showError('Please fill in all required fields');
            return;
        }
        
        // Show loading state
        const submitBtn = form.querySelector('button[type="submit"]');
        submitBtn.classList.add('loading');
        
        setTimeout(() => {
            const coverLetter = this.createCoverLetter(companyName, jobRole, additionalNotes);
            this.displayCoverLetter(coverLetter);
            
            form.style.display = 'none';
            result.style.display = 'block';
            submitBtn.classList.remove('loading');
        }, 1500);
    }
    
    createCoverLetter(company, role, notes) {
        const date = new Date().toLocaleDateString();
        
        return `Dear Hiring Manager,

I am writing to express my strong interest in the ${role} position at ${company}. As a passionate full-stack developer with a solid foundation in modern web technologies and a drive for continuous learning, I am excited about the opportunity to contribute to your team's success.

My technical journey began with HTML, CSS, and JavaScript, and has evolved to encompass Python, C programming, database management, and DevOps technologies including Docker, Kubernetes, and AWS. This diverse skill set, combined with my hands-on experience in building responsive web applications and mobile solutions, positions me well to tackle the challenges of the ${role} role.

What sets me apart is my ability to bridge the gap between complex technical concepts and user-friendly interfaces. I approach every project with empathy, asking not just "How can I build this?" but "How can I build this better?" This philosophy has guided me through projects ranging from cultural showcase websites to practical mobile applications like a public toilet locator app.

${notes ? `Additionally, ${notes.toLowerCase()}.` : ''}

I am particularly drawn to ${company} because of your commitment to innovation and excellence. I would welcome the opportunity to discuss how my technical skills, passion for problem-solving, and eagerness to learn can contribute to your team's continued success.

Thank you for considering my application. I look forward to hearing from you and am available for an interview at your convenience.

Best regards,
Sudhanshu Sharma
sudhanshu.sharma.vs@gmail.com
LinkedIn: linkedin.com/in/sudhanshu-sharma-1745b8324
GitHub: github.com/SuDhAnShU-shr

Date: ${date}`;
    }
    
    displayCoverLetter(letter) {
        const contentElement = document.getElementById('letter-content');
        if (contentElement) {
            contentElement.textContent = letter;
            this.currentLetter = letter;
        }
    }
    
    copyCoverLetter() {
        if (this.currentLetter) {
            navigator.clipboard.writeText(this.currentLetter).then(() => {
                this.showSuccess('Cover letter copied to clipboard!');
            }).catch(() => {
                this.showError('Failed to copy to clipboard');
            });
        }
    }
    
    downloadCoverLetter() {
        if (this.currentLetter) {
            const blob = new Blob([this.currentLetter], { type: 'text/plain' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = 'Cover_Letter_Sudhanshu_Sharma.txt';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);
            
            this.showSuccess('Cover letter downloaded successfully!');
        }
    }
    
    resetCoverLetterGenerator() {
        const form = document.getElementById('cover-letter-form');
        const result = document.getElementById('cover-letter-result');
        
        if (form) {
            form.style.display = 'block';
            form.reset();
        }
        if (result) result.style.display = 'none';
        
        this.currentLetter = null;
    }
    
    showError(message) {
        this.showNotification(message, 'error');
    }
    
    showSuccess(message) {
        this.showNotification(message, 'success');
    }
    
    showNotification(message, type) {
        // Use the global notification function if available
        if (window.showNotification) {
            window.showNotification(message, type);
        } else {
            alert(message);
        }
    }
}

// Initialize AI tools when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.aiTools = new AITools();
});