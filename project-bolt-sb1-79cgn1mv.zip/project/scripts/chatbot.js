// Chatbot functionality
class Chatbot {
    constructor() {
        this.container = document.getElementById('chatbot-container');
        this.header = document.getElementById('chatbot-header');
        this.body = document.getElementById('chatbot-body');
        this.messages = document.getElementById('chatbot-messages');
        this.input = document.getElementById('chatbot-input');
        this.sendBtn = document.getElementById('chatbot-send');
        this.toggle = document.getElementById('chatbot-toggle');
        
        this.isOpen = false;
        this.responses = this.initializeResponses();
        
        this.initialize();
    }
    
    initialize() {
        if (!this.container) return;
        
        // Toggle chatbot
        if (this.header) {
            this.header.addEventListener('click', () => this.toggleChat());
        }
        
        // Send message
        if (this.sendBtn) {
            this.sendBtn.addEventListener('click', () => this.sendMessage());
        }
        
        // Send on Enter
        if (this.input) {
            this.input.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.sendMessage();
                }
            });
        }
        
        // Auto-focus input when opened
        this.container.addEventListener('transitionend', () => {
            if (this.isOpen && this.input) {
                this.input.focus();
            }
        });
    }
    
    toggleChat() {
        this.isOpen = !this.isOpen;
        this.container.classList.toggle('open', this.isOpen);
        
        if (this.isOpen && this.input) {
            setTimeout(() => this.input.focus(), 300);
        }
    }
    
    sendMessage() {
        const message = this.input.value.trim();
        if (!message) return;
        
        // Add user message
        this.addMessage(message, 'user');
        
        // Clear input
        this.input.value = '';
        
        // Show typing indicator
        this.showTypingIndicator();
        
        // Generate response
        setTimeout(() => {
            this.hideTypingIndicator();
            const response = this.generateResponse(message);
            this.addMessage(response, 'bot');
        }, 1000 + Math.random() * 1000);
    }
    
    addMessage(text, sender) {
        const message = document.createElement('div');
        message.className = `message ${sender}-message`;
        
        const content = document.createElement('div');
        content.className = 'message-content';
        content.textContent = text;
        
        message.appendChild(content);
        this.messages.appendChild(message);
        
        // Scroll to bottom
        this.messages.scrollTop = this.messages.scrollHeight;
    }
    
    showTypingIndicator() {
        const indicator = document.createElement('div');
        indicator.className = 'message bot-message typing-indicator';
        indicator.innerHTML = `
            <div class="message-content">
                <div class="typing-dots">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        `;
        
        // Add CSS for typing animation
        if (!document.getElementById('typing-styles')) {
            const style = document.createElement('style');
            style.id = 'typing-styles';
            style.textContent = `
                .typing-dots {
                    display: flex;
                    gap: 2px;
                }
                .typing-dots span {
                    width: 6px;
                    height: 6px;
                    border-radius: 50%;
                    background: #666;
                    animation: typing 1.4s infinite ease-in-out;
                }
                .typing-dots span:nth-child(1) { animation-delay: -0.32s; }
                .typing-dots span:nth-child(2) { animation-delay: -0.16s; }
                @keyframes typing {
                    0%, 80%, 100% { transform: scale(0); opacity: 0.5; }
                    40% { transform: scale(1); opacity: 1; }
                }
            `;
            document.head.appendChild(style);
        }
        
        this.messages.appendChild(indicator);
        this.messages.scrollTop = this.messages.scrollHeight;
    }
    
    hideTypingIndicator() {
        const indicator = this.messages.querySelector('.typing-indicator');
        if (indicator) {
            this.messages.removeChild(indicator);
        }
    }
    
    generateResponse(message) {
        const lowerMessage = message.toLowerCase();
        
        // Find best matching response
        for (const pattern in this.responses) {
            if (lowerMessage.includes(pattern)) {
                const responses = this.responses[pattern];
                return responses[Math.floor(Math.random() * responses.length)];
            }
        }
        
        // Default responses
        const defaultResponses = [
            "That's interesting! Tell me more about what you'd like to know about Sudhanshu.",
            "I'm here to help! You can ask me about Sudhanshu's skills, projects, or experience.",
            "Feel free to ask me anything about Sudhanshu's technical background or career goals.",
            "I'd be happy to help! Try asking about technologies, projects, or how to get in touch."
        ];
        
        return defaultResponses[Math.floor(Math.random() * defaultResponses.length)];
    }
    
    initializeResponses() {
        return {
            'hello': [
                "Hello! I'm Sudhanshu's AI assistant. How can I help you today?",
                "Hi there! I'm here to answer questions about Sudhanshu's skills and experience.",
                "Hello! Welcome to Sudhanshu's portfolio. What would you like to know?"
            ],
            'hi': [
                "Hi! I'm here to help you learn more about Sudhanshu.",
                "Hello! Feel free to ask me anything about Sudhanshu's work.",
                "Hi there! What brings you to Sudhanshu's portfolio today?"
            ],
            'technologies': [
                "Sudhanshu works with HTML5, CSS3, JavaScript, Python, C, Linux, Docker, Kubernetes, AWS, Jenkins, Flask, and MongoDB. He's particularly strong in frontend development and expanding into DevOps.",
                "His tech stack includes frontend (HTML, CSS, JS), backend (Python, C), databases (DBMS, MongoDB), and cloud/DevOps tools (Linux, Docker, K8s, AWS, Jenkins).",
                "Sudhanshu has expertise in web development technologies and is actively learning cloud and DevOps tools. Check out the skills section for detailed proficiency levels!"
            ],
            'skills': [
                "Sudhanshu has strong skills in HTML, CSS, JavaScript, Python, and C programming. He's also experienced with Linux, databases, and DevOps tools like Docker and Kubernetes.",
                "His core skills include frontend development, Python programming, and system administration. He's currently expanding into cloud technologies and DevOps practices.",
                "Technical skills include web development, programming languages (Python, C, JavaScript), database management, and cloud/DevOps technologies. All with hands-on project experience!"
            ],
            'projects': [
                "Sudhanshu has worked on several projects including Rajasthani Di Rasoi (a cultural website), a Public Toilet Locator App using React Native, and this interactive portfolio website with AI features!",
                "His featured projects showcase different skills: a static website demonstrating design skills, a mobile app showing React Native expertise, and this portfolio highlighting advanced web development.",
                "You can see his projects in the portfolio section above! Each project demonstrates different technical skills and problem-solving approaches."
            ],
            'experience': [
                "Sudhanshu has been actively developing for over a year, completing 15+ projects and continuously learning new technologies. He started with web fundamentals and has progressed to full-stack development.",
                "His experience includes frontend development, backend programming, database management, and DevOps practices. He's also volunteered at university events and earned several certifications.",
                "With 1+ years of hands-on development experience, Sudhanshu has built a strong foundation in multiple technologies while maintaining focus on practical, real-world applications."
            ],
            'contact': [
                "You can reach Sudhanshu at sudhanshu.sharma.vs@gmail.com or connect on LinkedIn at linkedin.com/in/sudhanshu-sharma-1745b8324. He's also active on GitHub!",
                "Contact information: Email - sudhanshu.sharma.vs@gmail.com, LinkedIn - sudhanshu-sharma-1745b8324, GitHub - SuDhAnShU-shr. He typically responds within 24 hours!",
                "Feel free to contact him via email or LinkedIn for opportunities, collaboration, or just to connect! You can also use the contact form on this website."
            ],
            'hire': [
                "Sudhanshu is actively seeking opportunities! He's passionate about building innovative solutions and would love to contribute to your team. Contact him to discuss how he can help!",
                "Yes, he's available for opportunities! With his diverse skill set and enthusiasm for learning, he'd be a great addition to any development team.",
                "Absolutely! Sudhanshu is looking for roles where he can apply his technical skills while continuing to grow. Reach out to discuss potential opportunities!"
            ],
            'resume': [
                "You can download his resume using the 'Download Resume' button in the hero section, or try typing 'sudo hire me' in the terminal for a fun surprise!",
                "His resume is available for download on this page! Click the download button or use the terminal feature for an interactive experience.",
                "Resume download is available through the button above, and it includes all his technical skills, projects, and experience details."
            ],
            'location': [
                "Sudhanshu is currently based in Phagwara, Punjab, India. He's open to remote opportunities and willing to relocate for the right position!",
                "He's located in Phagwara, Punjab, India, and is flexible about remote work arrangements or relocation for career opportunities.",
                "Based in Phagwara, Punjab, India. Open to both local and remote opportunities, as well as relocation for the right role!"
            ],
            'learning': [
                "Sudhanshu is constantly learning! He started with HTML/CSS in August 2024 and has progressively added Python, C, databases, and DevOps tools to his skill set.",
                "His learning journey shows consistent growth: web fundamentals → Python programming → system programming → DevOps and cloud technologies. Always expanding his expertise!",
                "He believes in continuous learning and stays updated with latest technologies. Currently focusing on advanced DevOps practices and cloud architecture."
            ],
            'passion': [
                "Sudhanshu is passionate about solving real-world problems through technology. He believes in creating user-friendly solutions that make a positive impact.",
                "His passion lies in building innovative digital solutions and bridging the gap between complex technical concepts and user-friendly interfaces.",
                "He's driven by the opportunity to use technology for good - creating solutions that are both technically excellent and genuinely helpful to users."
            ],
            'portfolio': [
                "This portfolio itself showcases his skills! It features interactive elements, AI tools, a terminal interface, multilingual support, and responsive design.",
                "The portfolio demonstrates advanced web development skills including animations, API integration, responsive design, and user experience focus.",
                "You're experiencing his work right now! This portfolio includes AI features, interactive elements, and modern web development practices."
            ]
        };
    }
}

// Initialize chatbot when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.chatbot = new Chatbot();
});