// Code Sandbox functionality
class CodeSandbox {
    constructor() {
        this.htmlEditor = document.getElementById('html-editor');
        this.cssEditor = document.getElementById('css-editor');
        this.jsEditor = document.getElementById('js-editor');
        this.previewFrame = document.getElementById('preview-frame');
        this.resetBtn = document.getElementById('reset-code');
        this.fullscreenBtn = document.getElementById('fullscreen-sandbox');
        
        this.defaultCode = {
            html: `<div class="container">
  <h1>Welcome to Code Sandbox!</h1>
  <button class="animated-btn" onclick="showMessage()">
    Click Me!
  </button>
  <div id="message"></div>
</div>`,
            css: `.container {
  padding: 20px;
  font-family: 'Inter', sans-serif;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: white;
}

h1 {
  font-size: 2.5rem;
  margin-bottom: 2rem;
  text-align: center;
  text-shadow: 0 2px 4px rgba(0,0,0,0.3);
}

.animated-btn {
  background: #3B82F6;
  color: white;
  border: none;
  padding: 1rem 2rem;
  border-radius: 0.5rem;
  font-size: 1.1rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}

.animated-btn:hover {
  background: #1E40AF;
  transform: translateY(-2px);
  box-shadow: 0 8px 15px rgba(0,0,0,0.2);
}

.animated-btn:active {
  transform: translateY(0);
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

#message {
  margin-top: 2rem;
  padding: 1rem;
  background: rgba(255,255,255,0.1);
  border-radius: 0.5rem;
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255,255,255,0.2);
  text-align: center;
  min-height: 60px;
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transition: all 0.3s ease;
}

#message.show {
  opacity: 1;
  transform: scale(1.05);
}`,
            js: `function showMessage() {
  const messages = [
    "Hello from the sandbox! 👋",
    "Great job clicking the button! 🎉",
    "You're exploring the code sandbox! 🚀",
    "Keep experimenting with the code! 💻",
    "This is interactive coding! ✨"
  ];
  
  const messageElement = document.getElementById('message');
  const randomMessage = messages[Math.floor(Math.random() * messages.length)];
  
  messageElement.textContent = randomMessage;
  messageElement.classList.add('show');
  
  // Add some sparkle effect
  createSparkles();
}

function createSparkles() {
  const container = document.querySelector('.container');
  
  for (let i = 0; i < 10; i++) {
    const sparkle = document.createElement('div');
    sparkle.style.cssText = \`
      position: absolute;
      width: 4px;
      height: 4px;
      background: #FFD700;
      border-radius: 50%;
      pointer-events: none;
      left: \${Math.random() * 100}%;
      top: \${Math.random() * 100}%;
      animation: sparkle 1s ease-out forwards;
    \`;
    
    container.appendChild(sparkle);
    
    setTimeout(() => {
      if (container.contains(sparkle)) {
        container.removeChild(sparkle);
      }
    }, 1000);
  }
}

// Add sparkle animation if not exists
if (!document.getElementById('sparkle-styles')) {
  const style = document.createElement('style');
  style.id = 'sparkle-styles';
  style.textContent = \`
    @keyframes sparkle {
      0% {
        transform: scale(0) rotate(0deg);
        opacity: 1;
      }
      100% {
        transform: scale(1) rotate(180deg);
        opacity: 0;
      }
    }
  \`;
  document.head.appendChild(style);
}`
        };
        
        this.initialize();
    }
    
    initialize() {
        if (!this.htmlEditor || !this.cssEditor || !this.jsEditor || !this.previewFrame) return;
        
        // Set default content
        this.htmlEditor.value = this.defaultCode.html;
        this.cssEditor.value = this.defaultCode.css;
        this.jsEditor.value = this.defaultCode.js;
        
        // Add event listeners for real-time preview
        this.htmlEditor.addEventListener('input', this.debounce(() => this.updatePreview(), 500));
        this.cssEditor.addEventListener('input', this.debounce(() => this.updatePreview(), 500));
        this.jsEditor.addEventListener('input', this.debounce(() => this.updatePreview(), 500));
        
        // Reset button
        if (this.resetBtn) {
            this.resetBtn.addEventListener('click', () => this.resetCode());
        }
        
        // Fullscreen button
        if (this.fullscreenBtn) {
            this.fullscreenBtn.addEventListener('click', () => this.toggleFullscreen());
        }
        
        // Initial preview
        this.updatePreview();
        
        // Add syntax highlighting effect
        this.addSyntaxHighlighting();
    }
    
    updatePreview() {
        const html = this.htmlEditor.value;
        const css = this.cssEditor.value;
        const js = this.jsEditor.value;
        
        const previewContent = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Code Preview</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }
        ${css}
    </style>
</head>
<body>
    ${html}
    <script>
        try {
            ${js}
        } catch (error) {
            console.error('JavaScript Error:', error);
            document.body.innerHTML += '<div style="position: fixed; top: 10px; right: 10px; background: #EF4444; color: white; padding: 0.5rem; border-radius: 4px; font-size: 0.8rem; z-index: 9999;">JS Error: ' + error.message + '</div>';
        }
    </script>
</body>
</html>`;
        
        // Update iframe
        const blob = new Blob([previewContent], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        this.previewFrame.src = url;
        
        // Clean up previous URL
        setTimeout(() => URL.revokeObjectURL(url), 1000);
    }
    
    resetCode() {
        this.htmlEditor.value = this.defaultCode.html;
        this.cssEditor.value = this.defaultCode.css;
        this.jsEditor.value = this.defaultCode.js;
        this.updatePreview();
        
        this.showNotification('Code reset to default template', 'success');
    }
    
    toggleFullscreen() {
        const sandbox = document.querySelector('.code-sandbox');
        if (!sandbox) return;
        
        if (!document.fullscreenElement) {
            sandbox.requestFullscreen().then(() => {
                sandbox.classList.add('fullscreen');
                this.fullscreenBtn.innerHTML = '<i class="fas fa-compress"></i> Exit Fullscreen';
            }).catch(err => {
                console.error('Error entering fullscreen:', err);
                this.showNotification('Fullscreen not supported', 'error');
            });
        } else {
            document.exitFullscreen().then(() => {
                sandbox.classList.remove('fullscreen');
                this.fullscreenBtn.innerHTML = '<i class="fas fa-expand"></i> Fullscreen';
            });
        }
    }
    
    addSyntaxHighlighting() {
        // Add basic syntax highlighting with CSS
        const style = document.createElement('style');
        style.textContent = `
            .code-editor {
                font-family: 'Fira Code', 'Monaco', 'Menlo', monospace !important;
                line-height: 1.5;
                tab-size: 2;
            }
            
            .code-editor:focus {
                outline: 2px solid #3B82F6;
                outline-offset: -2px;
            }
            
            .sandbox-content.fullscreen {
                position: fixed;
                top: 0;
                left: 0;
                width: 100vw;
                height: 100vh;
                z-index: 9999;
                background: white;
            }
            
            .sandbox-content.fullscreen .editor-panels {
                height: 60vh;
            }
            
            .sandbox-content.fullscreen .preview-panel {
                height: 40vh;
            }
        `;
        document.head.appendChild(style);
        
        // Add line numbers (basic implementation)
        this.addLineNumbers();
    }
    
    addLineNumbers() {
        [this.htmlEditor, this.cssEditor, this.jsEditor].forEach(editor => {
            if (!editor) return;
            
            editor.addEventListener('scroll', (e) => {
                // Sync scroll with line numbers if implemented
            });
            
            editor.addEventListener('input', (e) => {
                // Update line numbers if implemented
            });
        });
    }
    
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
    
    showNotification(message, type) {
        // Use global notification function if available
        if (window.showNotification) {
            window.showNotification(message, type);
        } else {
            console.log(`${type.toUpperCase()}: ${message}`);
        }
    }
}

// Initialize code sandbox when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.codeSandbox = new CodeSandbox();
});